"""
reports/notification_engine.py
--------------------------------
Evaluates processed data against threshold rules and generates
structured alert objects.

Alert types:
  - LIMIT_EXCEEDED     : app used beyond daily limit
  - HIGH_SCREEN_TIME   : daily total > personal baseline + threshold
  - LONG_SESSION       : single session > N minutes for unproductive app
  - SOCIAL_SPIRAL      : social media > 3 hrs/day
  - LATE_NIGHT_USAGE   : unproductive app used after 11 PM
  - GAMING_STREAK      : continuous gaming session > 90 mins
  - PRODUCTIVITY_DROP  : weekly avg productivity down > 15%
  - STUDY_PRAISE       : education > 2 hrs — positive reinforcement
  - PREDICTION_WARNING : ML forecast predicts high unproductive day tomorrow
"""

import pandas as pd
import numpy as np
import json
import logging
import os
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta

log = logging.getLogger(__name__)


SEVERITY_LEVELS = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}


@dataclass
class Alert:
    alert_id:    str
    user_id:     str
    alert_type:  str
    severity:    str        # critical | high | medium | low | info
    title:       str
    message:     str
    app_name:    str | None
    value:       float | None   # e.g. minutes used
    threshold:   float | None   # e.g. limit in minutes
    date:        str
    action:      str            # recommended user action


def _aid(prefix, user, date, app=""):
    return f"{prefix}_{user}_{date}_{app}".replace(" ", "_")


# ── Rule Evaluators ────────────────────────────────────────────────────────────

def check_limit_exceeded(app_daily: pd.DataFrame) -> list[Alert]:
    alerts = []
    exceeded = app_daily[app_daily["limit_exceeded"] == True]
    for _, row in exceeded.iterrows():
        overage = row.get("overage_minutes", 0)
        severity = "high" if overage > 30 else "medium"
        alerts.append(Alert(
            alert_id  = _aid("LIMIT", row["user_id"], row["date"], row["app_name"]),
            user_id   = str(row["user_id"]),
            alert_type= "LIMIT_EXCEEDED",
            severity  = severity,
            title     = f"{row['app_name']} — daily limit exceeded",
            message   = (f"You used {row['app_name']} for "
                         f"{row['total_duration_minutes']:.0f} min today. "
                         f"Your limit is {row['daily_limit_minutes']:.0f} min "
                         f"(+{overage:.0f} min over)."),
            app_name  = row["app_name"],
            value     = row["total_duration_minutes"],
            threshold = row["daily_limit_minutes"],
            date      = str(row["date"]),
            action    = f"Close {row['app_name']} and take a break.",
        ))
    return alerts


def check_high_screen_time(day_summary: pd.DataFrame,
                            threshold_hrs: float = 6.0) -> list[Alert]:
    alerts = []
    high = day_summary[day_summary["total_screen_time_hours"] > threshold_hrs]
    for _, row in high.iterrows():
        excess = row["total_screen_time_hours"] - threshold_hrs
        alerts.append(Alert(
            alert_id  = _aid("HIGH_ST", row["user_id"], row["date"]),
            user_id   = str(row["user_id"]),
            alert_type= "HIGH_SCREEN_TIME",
            severity  = "high" if excess > 2 else "medium",
            title     = "High screen time today",
            message   = (f"Total screen time: {row['total_screen_time_hours']:.1f} hrs "
                         f"({excess:.1f} hrs above your {threshold_hrs:.0f}-hr guideline)."),
            app_name  = None,
            value     = row["total_screen_time_hours"],
            threshold = threshold_hrs,
            date      = str(row["date"]),
            action    = "Schedule a no-phone hour before bedtime.",
        ))
    return alerts


def check_long_sessions(session_df: pd.DataFrame,
                         limit_mins: float = 90.0) -> list[Alert]:
    alerts = []
    unp = session_df[session_df["is_unproductive"] == True]
    long_sess = unp[unp["duration_minutes"] > limit_mins]
    for _, row in long_sess.iterrows():
        alerts.append(Alert(
            alert_id  = _aid("LONG", row["user_id"], str(row["date"]), row["app_name"]),
            user_id   = str(row["user_id"]),
            alert_type= "LONG_SESSION",
            severity  = "high",
            title     = f"Long {row['category']} session on {row['app_name']}",
            message   = (f"You had a {row['duration_minutes']:.0f}-min session on "
                         f"{row['app_name']}. Continuous use of "
                         f"{row['category'].lower()} apps for this long can hurt focus."),
            app_name  = row["app_name"],
            value     = row["duration_minutes"],
            threshold = limit_mins,
            date      = str(row["date"]),
            action    = "Stand up, stretch, or switch to a productive app.",
        ))
    return alerts


def check_social_spiral(app_daily: pd.DataFrame,
                         limit_mins: float = 180.0) -> list[Alert]:
    alerts = []
    sm = (
        app_daily[app_daily["category"] == "Social Media"]
        .groupby(["user_id", "date"])["total_duration_minutes"]
        .sum()
        .reset_index()
    )
    spirals = sm[sm["total_duration_minutes"] > limit_mins]
    for _, row in spirals.iterrows():
        alerts.append(Alert(
            alert_id  = _aid("SM_SPIRAL", row["user_id"], row["date"]),
            user_id   = str(row["user_id"]),
            alert_type= "SOCIAL_SPIRAL",
            severity  = "high",
            title     = "Social media usage is very high today",
            message   = (f"You spent {row['total_duration_minutes']:.0f} min "
                         f"({row['total_duration_minutes']/60:.1f} hrs) on social media today. "
                         f"The recommended limit is {limit_mins:.0f} min."),
            app_name  = None,
            value     = row["total_duration_minutes"],
            threshold = limit_mins,
            date      = str(row["date"]),
            action    = "Try a 24-hour social media detox tomorrow.",
        ))
    return alerts


def check_late_night(session_df: pd.DataFrame) -> list[Alert]:
    alerts = []
    df = session_df.copy()
    df["start_time"] = pd.to_datetime(df["start_time"])
    df["hour"] = df["start_time"].dt.hour
    late = df[(df["is_unproductive"] == True) & (df["hour"] >= 23)]
    late_days = late.drop_duplicates(subset=["user_id", "date"])
    for _, row in late_days.iterrows():
        alerts.append(Alert(
            alert_id  = _aid("LATE", row["user_id"], str(row["date"])),
            user_id   = str(row["user_id"]),
            alert_type= "LATE_NIGHT_USAGE",
            severity  = "medium",
            title     = "Late-night app usage detected",
            message   = (f"You were using {row['app_name']} after 11 PM on {row['date']}. "
                         f"Late-night screen time can disrupt sleep quality."),
            app_name  = row["app_name"],
            value     = row["hour"],
            threshold = 23,
            date      = str(row["date"]),
            action    = "Enable Do Not Disturb mode after 10:30 PM.",
        ))
    return alerts


def check_gaming_streak(session_df: pd.DataFrame,
                         limit_mins: float = 90.0) -> list[Alert]:
    alerts = []
    gaming = session_df[
        (session_df["category"] == "Gaming") &
        (session_df["duration_minutes"] > limit_mins)
    ]
    for _, row in gaming.iterrows():
        alerts.append(Alert(
            alert_id  = _aid("GAME_STREAK", row["user_id"], str(row["date"]), row["app_name"]),
            user_id   = str(row["user_id"]),
            alert_type= "GAMING_STREAK",
            severity  = "medium",
            title     = f"Long gaming session — {row['app_name']}",
            message   = (f"You played {row['app_name']} for "
                         f"{row['duration_minutes']:.0f} min straight. "
                         f"Take a break every {limit_mins:.0f} min."),
            app_name  = row["app_name"],
            value     = row["duration_minutes"],
            threshold = limit_mins,
            date      = str(row["date"]),
            action    = "Take a 15-minute break before the next session.",
        ))
    return alerts


def check_productivity_drop(weekly_df: pd.DataFrame,
                             drop_threshold: float = 15.0) -> list[Alert]:
    alerts = []
    df = weekly_df.sort_values(["user_id", "week_number"])
    df["prev_productivity"] = df.groupby("user_id")["avg_productivity_pct"].shift(1)
    df["delta"] = df["avg_productivity_pct"] - df["prev_productivity"]
    drops = df[df["delta"] < -drop_threshold].dropna(subset=["delta"])
    for _, row in drops.iterrows():
        alerts.append(Alert(
            alert_id  = _aid("PROD_DROP", row["user_id"], f"W{row['week_number']}"),
            user_id   = str(row["user_id"]),
            alert_type= "PRODUCTIVITY_DROP",
            severity  = "high",
            title     = "Productivity score dropped this week",
            message   = (f"Your weekly productivity fell by {abs(row['delta']):.1f}% "
                         f"(from {row['prev_productivity']:.1f}% to "
                         f"{row['avg_productivity_pct']:.1f}%). "
                         f"Consider reviewing your app limits."),
            app_name  = None,
            value     = row["avg_productivity_pct"],
            threshold = row["prev_productivity"],
            date      = f"Week {int(row['week_number'])}",
            action    = "Review app limits and add educational apps to your routine.",
        ))
    return alerts


def check_study_praise(app_daily: pd.DataFrame,
                        praise_mins: float = 120.0) -> list[Alert]:
    alerts = []
    edu = (
        app_daily[app_daily["category"] == "Education"]
        .groupby(["user_id", "date"])["total_duration_minutes"]
        .sum()
        .reset_index()
    )
    good = edu[edu["total_duration_minutes"] >= praise_mins]
    for _, row in good.iterrows():
        alerts.append(Alert(
            alert_id  = _aid("STUDY_PRAISE", row["user_id"], row["date"]),
            user_id   = str(row["user_id"]),
            alert_type= "STUDY_PRAISE",
            severity  = "info",
            title     = "Great study session today!",
            message   = (f"You spent {row['total_duration_minutes']:.0f} min on educational "
                         f"apps today. Keep building that streak!"),
            app_name  = None,
            value     = row["total_duration_minutes"],
            threshold = praise_mins,
            date      = str(row["date"]),
            action    = "Maintain this streak — try +15 min tomorrow.",
        ))
    return alerts


def check_prediction_warning(predictions: pd.DataFrame) -> list[Alert]:
    """Alert if tomorrow's unproductive prediction is > 3 hrs."""
    alerts = []
    if predictions.empty:
        return alerts

    tomorrow = (datetime.today() + timedelta(days=1)).strftime("%Y-%m-%d")
    tom_preds = predictions[predictions["forecast_date"] == tomorrow]
    if tom_preds.empty:
        return alerts

    unp = tom_preds[tom_preds["productivity_label"] == "Unproductive"]
    unp_total = unp.groupby("user_id")["predicted_minutes"].sum().reset_index()

    for _, row in unp_total[unp_total["predicted_minutes"] > 180].iterrows():
        top_app = unp.loc[unp["predicted_minutes"].idxmax(), "app_name"]
        alerts.append(Alert(
            alert_id  = _aid("PRED_WARN", row["user_id"], tomorrow),
            user_id   = str(row["user_id"]),
            alert_type= "PREDICTION_WARNING",
            severity  = "medium",
            title     = "High unproductive usage predicted tomorrow",
            message   = (f"Based on your patterns, you're forecast to spend "
                         f"{row['predicted_minutes']:.0f} min on unproductive apps tomorrow "
                         f"(mostly {top_app}). Set limits in advance."),
            app_name  = top_app,
            value     = row["predicted_minutes"],
            threshold = 180,
            date      = tomorrow,
            action    = "Enable Focus Mode for tomorrow evening.",
        ))
    return alerts


# ── Master runner ──────────────────────────────────────────────────────────────

def run_notifications(session_df, app_daily, day_summary,
                       weekly_df, predictions=None,
                       output_dir: str = "data") -> list[Alert]:
    """Run all notification checks and save as JSON."""
    os.makedirs(output_dir, exist_ok=True)

    all_alerts = []
    all_alerts += check_limit_exceeded(app_daily)
    all_alerts += check_high_screen_time(day_summary)
    all_alerts += check_long_sessions(session_df)
    all_alerts += check_social_spiral(app_daily)
    all_alerts += check_late_night(session_df)
    all_alerts += check_gaming_streak(session_df)
    all_alerts += check_productivity_drop(weekly_df)
    all_alerts += check_study_praise(app_daily)
    if predictions is not None and not predictions.empty:
        all_alerts += check_prediction_warning(predictions)

    # Sort by severity descending
    all_alerts.sort(
        key=lambda a: SEVERITY_LEVELS.get(a.severity, 0),
        reverse=True
    )

    # Save
    out_path = os.path.join(output_dir, "alerts.json")
    with open(out_path, "w") as f:
        json.dump([asdict(a) for a in all_alerts], f, indent=2)

    # Also CSV
    pd.DataFrame([asdict(a) for a in all_alerts]).to_csv(
        os.path.join(output_dir, "alerts.csv"), index=False
    )

    log.info(f"Generated {len(all_alerts)} alerts → {out_path}")
    for sev in ["critical", "high", "medium", "low", "info"]:
        count = sum(1 for a in all_alerts if a.severity == sev)
        if count:
            log.info(f"  {sev.upper()}: {count}")

    return all_alerts


if __name__ == "__main__":
    import pandas as pd
    session_df  = pd.read_csv("data/processed_sessions.csv")
    app_daily   = pd.read_csv("data/app_daily_summary.csv")
    day_summary = pd.read_csv("data/daily_summary.csv")
    weekly_df   = pd.read_csv("data/weekly_summary.csv")

    try:
        predictions = pd.read_csv("data/predictions.csv")
    except FileNotFoundError:
        predictions = pd.DataFrame()

    alerts = run_notifications(session_df, app_daily, day_summary, weekly_df, predictions)
    print(f"\nTotal alerts: {len(alerts)}")
    for a in alerts[:5]:
        print(f"  [{a.severity.upper()}] {a.title}")
