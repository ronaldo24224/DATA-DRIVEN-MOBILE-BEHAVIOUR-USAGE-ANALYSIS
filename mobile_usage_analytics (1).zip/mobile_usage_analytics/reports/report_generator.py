"""
reports/report_generator.py
----------------------------
Generates rich HTML reports (weekly & monthly) from processed data.
Also exports a clean processed CSV dataset.
"""

import pandas as pd
import numpy as np
import os
import logging
from datetime import datetime
from jinja2 import Template

log = logging.getLogger(__name__)

# ── HTML Template ──────────────────────────────────────────────────────────────

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{{ title }}</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
         background: #f5f5f3; color: #1a1a18; font-size: 14px; }
  .container { max-width: 900px; margin: 0 auto; padding: 32px 24px; }
  h1 { font-size: 26px; font-weight: 600; margin-bottom: 4px; }
  h2 { font-size: 16px; font-weight: 600; margin: 32px 0 14px; color: #444; border-bottom: 1px solid #e0e0da; padding-bottom: 8px; }
  .subtitle { color: #888; font-size: 13px; margin-bottom: 32px; }

  /* Metric cards */
  .metrics { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 32px; }
  .metric { background: #fff; border: 1px solid #e0e0da; border-radius: 10px; padding: 16px; }
  .metric-label { font-size: 11px; color: #888; font-weight: 600; text-transform: uppercase; letter-spacing: .06em; margin-bottom: 6px; }
  .metric-value { font-size: 24px; font-weight: 600; }
  .metric-sub   { font-size: 12px; margin-top: 4px; }
  .green { color: #1D9E75; } .red { color: #D85A30; } .orange { color: #BA7517; } .blue { color: #185FA5; }

  /* Table */
  table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 10px; overflow: hidden; border: 1px solid #e0e0da; }
  th { background: #f0ede6; padding: 10px 12px; text-align: left; font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing:.04em; color: #666; }
  td { padding: 9px 12px; border-top: 1px solid #f0ede6; font-size: 13px; }
  tr:hover td { background: #faf9f7; }

  /* Badge */
  .badge { display: inline-block; padding: 2px 8px; border-radius: 20px; font-size: 11px; font-weight: 600; }
  .badge-green  { background: #E1F5EE; color: #0F6E56; }
  .badge-red    { background: #FAECE7; color: #993C1D; }
  .badge-orange { background: #FAEEDA; color: #854F0B; }

  /* Progress bar */
  .bar-wrap { background: #f0ede6; border-radius: 4px; height: 8px; overflow: hidden; }
  .bar-fill { height: 8px; border-radius: 4px; }

  /* Alert */
  .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 8px; border-left: 4px solid; }
  .alert-high   { background: #FAECE7; border-color: #D85A30; }
  .alert-medium { background: #FAEEDA; border-color: #BA7517; }
  .alert-info   { background: #E1F5EE; border-color: #1D9E75; }
  .alert-title  { font-weight: 600; font-size: 13px; }
  .alert-msg    { font-size: 12px; color: #555; margin-top: 2px; }

  .section-card { background: #fff; border: 1px solid #e0e0da; border-radius: 10px; padding: 20px; margin-bottom: 20px; }
  footer { text-align: center; color: #aaa; font-size: 12px; margin-top: 48px; padding-top: 24px; border-top: 1px solid #e0e0da; }
</style>
</head>
<body>
<div class="container">
  <h1>{{ title }}</h1>
  <div class="subtitle">Generated on {{ generated_at }} &nbsp;·&nbsp; Period: {{ period }}</div>

  <div class="metrics">
    <div class="metric">
      <div class="metric-label">Avg Daily Screen Time</div>
      <div class="metric-value {{ 'red' if avg_screen > 6 else 'green' }}">{{ avg_screen }}h</div>
      <div class="metric-sub">{{ total_screen }}h total</div>
    </div>
    <div class="metric">
      <div class="metric-label">Avg Productivity</div>
      <div class="metric-value {{ 'green' if avg_prod >= 60 else 'orange' if avg_prod >= 40 else 'red' }}">{{ avg_prod }}%</div>
      <div class="metric-sub">{{ prod_label }}</div>
    </div>
    <div class="metric">
      <div class="metric-label">Unproductive Time</div>
      <div class="metric-value red">{{ avg_unprod }}h/day</div>
      <div class="metric-sub">{{ unprod_pct }}% of screen time</div>
    </div>
    <div class="metric">
      <div class="metric-label">Alerts Generated</div>
      <div class="metric-value blue">{{ alert_count }}</div>
      <div class="metric-sub">{{ high_alerts }} high priority</div>
    </div>
  </div>

  <h2>Daily Breakdown</h2>
  <div class="section-card" style="padding:0;overflow:hidden;">
  <table>
    <thead><tr><th>Date</th><th>Day</th><th>Screen Time</th><th>Productive</th><th>Unproductive</th><th>Score</th><th>Status</th></tr></thead>
    <tbody>
    {% for row in daily_rows %}
    <tr>
      <td>{{ row.date }}</td>
      <td>{{ row.day }}</td>
      <td>{{ row.screen_time }}h</td>
      <td class="green">{{ row.productive }}h</td>
      <td class="red">{{ row.unproductive }}h</td>
      <td><b>{{ row.score }}%</b></td>
      <td><span class="badge {{ row.badge_class }}">{{ row.badge }}</span></td>
    </tr>
    {% endfor %}
    </tbody>
  </table>
  </div>

  <h2>Top Apps by Usage</h2>
  <div class="section-card" style="padding:0;overflow:hidden;">
  <table>
    <thead><tr><th>App</th><th>Category</th><th>Total Time</th><th>Sessions</th><th>Productivity</th><th>Usage Bar</th></tr></thead>
    <tbody>
    {% for app in top_apps %}
    <tr>
      <td><b>{{ app.name }}</b></td>
      <td>{{ app.category }}</td>
      <td>{{ app.total_time }}</td>
      <td>{{ app.sessions }}</td>
      <td><span class="badge {{ app.badge_class }}">{{ app.prod_label }}</span></td>
      <td style="width:120px;">
        <div class="bar-wrap"><div class="bar-fill" style="width:{{ app.bar_pct }}%;background:{{ app.bar_color }};"></div></div>
      </td>
    </tr>
    {% endfor %}
    </tbody>
  </table>
  </div>

  <h2>Category Distribution</h2>
  <div class="section-card" style="padding:0;overflow:hidden;">
  <table>
    <thead><tr><th>Category</th><th>Total Time (mins)</th><th>% of Screen Time</th><th>Distribution</th></tr></thead>
    <tbody>
    {% for cat in categories %}
    <tr>
      <td>{{ cat.name }}</td>
      <td>{{ cat.total_mins }}m</td>
      <td>{{ cat.pct }}%</td>
      <td style="width:140px;">
        <div class="bar-wrap"><div class="bar-fill" style="width:{{ cat.pct }}%;background:{{ cat.color }};"></div></div>
      </td>
    </tr>
    {% endfor %}
    </tbody>
  </table>
  </div>

  {% if alerts %}
  <h2>Alerts & Recommendations</h2>
  {% for alert in alerts %}
  <div class="alert alert-{{ 'high' if alert.severity in ['critical','high'] else 'medium' if alert.severity == 'medium' else 'info' }}">
    <div class="alert-title">{{ alert.title }}</div>
    <div class="alert-msg">{{ alert.message }} — <em>{{ alert.action }}</em></div>
  </div>
  {% endfor %}
  {% endif %}

  <footer>
    Mobile Behaviour Usage Analytics &nbsp;·&nbsp; Auto-generated report &nbsp;·&nbsp; {{ generated_at }}
  </footer>
</div>
</body>
</html>
"""


# ── Helpers ────────────────────────────────────────────────────────────────────

def _badge(score):
    if score >= 65: return ("Productive",    "badge-green")
    if score >= 45: return ("Moderate",      "badge-orange")
    return                  ("Unproductive", "badge-red")


CAT_COLORS = {
    "Education":     "#1D9E75",
    "Productivity":  "#185FA5",
    "Communication": "#5DCAA5",
    "Utility":       "#888780",
    "Entertainment": "#BA7517",
    "Social Media":  "#D85A30",
    "Gaming":        "#993C1D",
    "Unknown":       "#888780",
}

APP_PROD_COLORS = {
    "Productive":   "#1D9E75",
    "Neutral":      "#BA7517",
    "Unproductive": "#D85A30",
}


def _fmt_mins(mins):
    h, m = divmod(int(mins), 60)
    return f"{h}h {m:02d}m" if h else f"{m}m"


# ── Report Builder ─────────────────────────────────────────────────────────────

def build_report(day_summary: pd.DataFrame,
                 app_daily:   pd.DataFrame,
                 session_df:  pd.DataFrame,
                 alerts:      list,
                 report_type: str = "weekly") -> str:
    """Render an HTML report string."""

    # ── Scope ──────────────────────────────────────────────────────────────────
    day_summary = day_summary.copy()
    day_summary["date"] = pd.to_datetime(day_summary["date"])
    day_summary = day_summary.sort_values("date").tail(7 if report_type == "weekly" else 30)

    period = f"{day_summary['date'].min().strftime('%b %d')} – {day_summary['date'].max().strftime('%b %d, %Y')}"

    # ── Headline metrics ───────────────────────────────────────────────────────
    avg_screen   = round(day_summary["total_screen_time_hours"].mean(), 1)
    total_screen = round(day_summary["total_screen_time_hours"].sum(), 1)
    avg_prod     = round(day_summary["productivity_pct"].mean(), 1)
    avg_unprod_h = round(day_summary["unproductive_minutes"].mean() / 60, 1)
    unprod_pct   = round(avg_unprod_h / avg_screen * 100, 1) if avg_screen else 0
    prod_label   = "Good" if avg_prod >= 60 else "Needs improvement" if avg_prod >= 40 else "Poor"

    high_alerts  = sum(1 for a in alerts if hasattr(a, "severity") and a.severity in ["critical","high"])

    # ── Daily rows ─────────────────────────────────────────────────────────────
    daily_rows = []
    for _, r in day_summary.iterrows():
        score = round(r.get("weighted_day_score", r["productivity_pct"]), 1)
        badge, badge_class = _badge(score)
        daily_rows.append({
            "date":         r["date"].strftime("%Y-%m-%d"),
            "day":          r["date"].strftime("%A"),
            "screen_time":  round(r["total_screen_time_hours"], 1),
            "productive":   round(r["productive_minutes"] / 60, 1),
            "unproductive": round(r["unproductive_minutes"] / 60, 1),
            "score":        score,
            "badge":        badge,
            "badge_class":  badge_class,
        })

    # ── Top apps ───────────────────────────────────────────────────────────────
    scope_dates = set(day_summary["date"].dt.strftime("%Y-%m-%d"))
    app_scope   = app_daily[app_daily["date"].astype(str).isin(scope_dates)]
    top_apps_df = (
        app_scope.groupby(["app_name", "category", "productivity_label"])
        .agg(total_mins=("total_duration_minutes","sum"), sessions=("session_count","sum"))
        .reset_index()
        .sort_values("total_mins", ascending=False)
        .head(10)
    )
    max_mins = top_apps_df["total_mins"].max()
    top_apps = []
    for _, r in top_apps_df.iterrows():
        top_apps.append({
            "name":       r["app_name"],
            "category":   r["category"],
            "total_time": _fmt_mins(r["total_mins"]),
            "sessions":   int(r["sessions"]),
            "prod_label": r["productivity_label"],
            "badge_class": (
                "badge-green"  if r["productivity_label"] == "Productive"  else
                "badge-red"    if r["productivity_label"] == "Unproductive" else
                "badge-orange"
            ),
            "bar_pct":   round(r["total_mins"] / max_mins * 100, 1),
            "bar_color": APP_PROD_COLORS.get(r["productivity_label"], "#888"),
        })

    # ── Category breakdown ─────────────────────────────────────────────────────
    cat_df = (
        app_scope.groupby("category")["total_duration_minutes"]
        .sum()
        .reset_index()
        .sort_values("total_duration_minutes", ascending=False)
    )
    total_cat_mins = cat_df["total_duration_minutes"].sum()
    categories = []
    for _, r in cat_df.iterrows():
        pct = round(r["total_duration_minutes"] / total_cat_mins * 100, 1) if total_cat_mins else 0
        categories.append({
            "name":       r["category"],
            "total_mins": round(r["total_duration_minutes"], 0),
            "pct":        pct,
            "color":      CAT_COLORS.get(r["category"], "#888"),
        })

    # ── Alerts (top 10) ────────────────────────────────────────────────────────
    alert_dicts = []
    for a in alerts[:10]:
        if hasattr(a, "title"):
            alert_dicts.append({"title": a.title, "message": a.message,
                                 "severity": a.severity, "action": a.action})

    # ── Render ─────────────────────────────────────────────────────────────────
    tpl = Template(HTML_TEMPLATE)
    return tpl.render(
        title        = f"{'Weekly' if report_type == 'weekly' else 'Monthly'} Usage Report",
        generated_at = datetime.now().strftime("%B %d, %Y %H:%M"),
        period       = period,
        avg_screen   = avg_screen,
        total_screen = total_screen,
        avg_prod     = avg_prod,
        prod_label   = prod_label,
        avg_unprod   = avg_unprod_h,
        unprod_pct   = unprod_pct,
        alert_count  = len(alerts),
        high_alerts  = high_alerts,
        daily_rows   = daily_rows,
        top_apps     = top_apps,
        categories   = categories,
        alerts       = alert_dicts,
    )


def export_processed_dataset(session_df: pd.DataFrame,
                              app_daily:  pd.DataFrame,
                              output_dir: str = "data") -> str:
    """Export the final clean processed dataset as CSV."""
    os.makedirs(output_dir, exist_ok=True)

    cols = [
        "user_id", "date", "app_name", "category", "productivity_label",
        "total_duration_minutes", "session_count", "avg_session_minutes",
        "max_session_minutes", "avg_productivity_score",
        "daily_limit_minutes", "limit_exceeded", "overage_minutes",
    ]
    available = [c for c in cols if c in app_daily.columns]
    export_df = app_daily[available].copy()
    export_df["date"] = pd.to_datetime(export_df["date"]).dt.strftime("%Y-%m-%d")

    path = os.path.join(output_dir, "processed_usage_dataset.csv")
    export_df.to_csv(path, index=False)
    log.info(f"Exported processed dataset: {path} ({len(export_df):,} rows)")
    return path


# ── Master runner ──────────────────────────────────────────────────────────────

def run_reports(day_summary, app_daily, session_df,
                alerts=None, output_dir="data") -> dict:
    """Generate weekly and monthly reports and export dataset."""
    os.makedirs(output_dir, exist_ok=True)
    alerts = alerts or []

    weekly_html  = build_report(day_summary, app_daily, session_df, alerts, "weekly")
    monthly_html = build_report(day_summary, app_daily, session_df, alerts, "monthly")

    weekly_path  = os.path.join(output_dir, "weekly_report.html")
    monthly_path = os.path.join(output_dir, "monthly_report.html")

    with open(weekly_path,  "w") as f: f.write(weekly_html)
    with open(monthly_path, "w") as f: f.write(monthly_html)

    dataset_path = export_processed_dataset(session_df, app_daily, output_dir)

    log.info(f"Weekly report:  {weekly_path}")
    log.info(f"Monthly report: {monthly_path}")

    return {
        "weekly_report":  weekly_path,
        "monthly_report": monthly_path,
        "dataset":        dataset_path,
    }


if __name__ == "__main__":
    import json
    from reports.notification_engine import Alert

    day_summary = pd.read_csv("data/daily_summary.csv")
    app_daily   = pd.read_csv("data/app_daily_summary.csv")
    session_df  = pd.read_csv("data/processed_sessions.csv")
    try:
        with open("data/alerts.json") as f:
            raw = json.load(f)
        alerts = [Alert(**a) for a in raw]
    except Exception:
        alerts = []

    paths = run_reports(day_summary, app_daily, session_df, alerts)
    print("Reports generated:")
    for k, v in paths.items():
        print(f"  {k}: {v}")
