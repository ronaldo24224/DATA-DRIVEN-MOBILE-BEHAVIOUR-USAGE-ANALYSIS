"""
dashboard/app.py
-----------------
Streamlit interactive dashboard for Mobile Behaviour Usage Analytics.

Launch:  streamlit run dashboard/app.py
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import json

# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Mobile Usage Analytics",
    page_icon="📱",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ─────────────────────────────────────────────────────────────────
st.markdown("""
<style>
  .block-container { padding-top: 1.5rem; }
  .metric-card { background: #fff; border: 1px solid #e0e0da; border-radius: 10px;
                 padding: 16px 20px; text-align: center; }
  .stMetric label { font-size: 12px !important; text-transform: uppercase;
                    letter-spacing: .05em; color: #888 !important; }
  div[data-testid="stMetricValue"] { font-size: 28px !important; }
</style>
""", unsafe_allow_html=True)

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")


# ── Data loaders ───────────────────────────────────────────────────────────────
@st.cache_data
def load_data():
    def safe_read(name):
        path = os.path.join(DATA_DIR, name)
        return pd.read_csv(path) if os.path.exists(path) else pd.DataFrame()

    sessions    = safe_read("processed_sessions.csv")
    app_daily   = safe_read("app_daily_summary.csv")
    day_summary = safe_read("daily_summary.csv")
    weekly      = safe_read("weekly_summary.csv")
    predictions = safe_read("predictions.csv")
    cat_trend   = safe_read("trend_cat_trend.csv")
    patterns    = safe_read("trend_patterns.csv")

    alerts = []
    alert_path = os.path.join(DATA_DIR, "alerts.json")
    if os.path.exists(alert_path):
        with open(alert_path) as f:
            alerts = json.load(f)

    return sessions, app_daily, day_summary, weekly, predictions, cat_trend, patterns, alerts


def run_pipeline_cached():
    """Trigger the pipeline from the dashboard."""
    import subprocess
    result = subprocess.run(
        [sys.executable, "pipeline.py"],
        cwd=os.path.join(os.path.dirname(__file__), ".."),
        capture_output=True, text=True
    )
    return result.returncode == 0, result.stdout, result.stderr


# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.title("📱 Mobile Analytics")
    st.markdown("---")

    if st.button("🔄 Re-run Pipeline", use_container_width=True):
        with st.spinner("Running pipeline..."):
            ok, stdout, stderr = run_pipeline_cached()
        if ok:
            st.success("Pipeline complete!")
            st.cache_data.clear()
            st.rerun()
        else:
            st.error("Pipeline failed.")
            st.code(stderr[:500])

    st.markdown("---")
    page = st.radio("Navigate", [
        "📊 Overview",
        "📈 Trends",
        "🤖 ML Predictions",
        "🔔 Alerts",
        "📁 Dataset",
    ])


# ── Load ───────────────────────────────────────────────────────────────────────
sessions, app_daily, day_summary, weekly, predictions, cat_trend, patterns, alerts = load_data()

if day_summary.empty:
    st.warning("No data found. Click **Re-run Pipeline** in the sidebar to generate data.")
    st.stop()

day_summary["date"] = pd.to_datetime(day_summary["date"])
day_summary = day_summary.sort_values("date")

COLOR_MAP = {
    "Education":     "#1D9E75",
    "Productivity":  "#185FA5",
    "Communication": "#5DCAA5",
    "Utility":       "#888780",
    "Entertainment": "#BA7517",
    "Social Media":  "#D85A30",
    "Gaming":        "#993C1D",
    "Unknown":       "#888780",
}


# ══════════════════════════════════════════════════════════════════════════════
# PAGE: OVERVIEW
# ══════════════════════════════════════════════════════════════════════════════
if page == "📊 Overview":
    st.header("📊 Overview")

    recent = day_summary.tail(7)

    # Metrics
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        avg_st = round(recent["total_screen_time_hours"].mean(), 1)
        st.metric("Avg Daily Screen Time", f"{avg_st}h",
                  delta=f"{round(avg_st - day_summary.head(7)['total_screen_time_hours'].mean(), 1)}h vs prev week")
    with c2:
        avg_prod = round(recent["productivity_pct"].mean(), 1)
        st.metric("Avg Productivity", f"{avg_prod}%",
                  delta=f"{round(avg_prod - day_summary.head(7)['productivity_pct'].mean(), 1)}%")
    with c3:
        avg_unprod = round(recent["unproductive_minutes"].mean() / 60, 1)
        st.metric("Unproductive Time/Day", f"{avg_unprod}h")
    with c4:
        apps_count = sessions["app_name"].nunique() if not sessions.empty else 0
        st.metric("Unique Apps Tracked", apps_count)

    st.markdown("---")
    col1, col2 = st.columns([1.6, 1])

    with col1:
        # Top apps bar chart
        if not app_daily.empty:
            st.subheader("Top Apps by Usage Time")
            top = (
                app_daily.groupby(["app_name", "category", "productivity_label"])["total_duration_minutes"]
                .sum().reset_index()
                .sort_values("total_duration_minutes", ascending=False)
                .head(12)
            )
            top["hours"] = (top["total_duration_minutes"] / 60).round(2)
            fig = px.bar(
                top, x="hours", y="app_name", orientation="h",
                color="category", color_discrete_map=COLOR_MAP,
                labels={"hours": "Total Hours", "app_name": ""},
                template="simple_white"
            )
            fig.update_layout(height=380, showlegend=True,
                              legend=dict(orientation="h", yanchor="bottom", y=1.02))
            st.plotly_chart(fig, use_container_width=True)

    with col2:
        # Category pie
        st.subheader("Category Distribution")
        if not app_daily.empty:
            cat_agg = (
                app_daily.groupby("category")["total_duration_minutes"]
                .sum().reset_index()
                .sort_values("total_duration_minutes", ascending=False)
            )
            fig2 = px.pie(cat_agg, names="category", values="total_duration_minutes",
                          color="category", color_discrete_map=COLOR_MAP,
                          template="simple_white", hole=0.4)
            fig2.update_layout(height=380, showlegend=True,
                               legend=dict(orientation="v"))
            st.plotly_chart(fig2, use_container_width=True)

    # Most frequent apps
    st.markdown("---")
    if not sessions.empty:
        st.subheader("Most Frequently Used Apps")
        freq = (
            sessions.groupby(["app_name", "category", "productivity_label"])
            .agg(sessions_count=("duration_minutes","count"),
                 total_hours=("duration_minutes", lambda x: round(x.sum()/60, 1)))
            .reset_index()
            .sort_values("sessions_count", ascending=False)
            .head(10)
        )
        freq["productivity_label"] = freq["productivity_label"].map({
            "Productive": "✅ Productive",
            "Unproductive": "❌ Unproductive",
            "Neutral": "🔶 Neutral"
        }).fillna(freq["productivity_label"])
        st.dataframe(freq, use_container_width=True, hide_index=True)


# ══════════════════════════════════════════════════════════════════════════════
# PAGE: TRENDS
# ══════════════════════════════════════════════════════════════════════════════
elif page == "📈 Trends":
    st.header("📈 Trend Analysis")

    # Screen time trend
    st.subheader("Daily Screen Time vs Productivity")
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=day_summary["date"], y=day_summary["total_screen_time_hours"],
        name="Screen Time (hrs)", fill="tozeroy",
        line=dict(color="#378ADD"), fillcolor="rgba(55,138,221,0.1)"
    ))
    fig.add_trace(go.Scatter(
        x=day_summary["date"], y=day_summary["productivity_pct"] / 10,
        name="Productivity Score (/10)", line=dict(color="#1D9E75", dash="dot"),
    ))
    fig.update_layout(template="simple_white", height=300,
                      yaxis_title="Hours / Score×10",
                      legend=dict(orientation="h"))
    st.plotly_chart(fig, use_container_width=True)

    # Category stacked area
    if not cat_trend.empty:
        st.subheader("Category Time Breakdown (Daily)")
        cat_trend["date"] = pd.to_datetime(cat_trend["date"])
        pivot = cat_trend.pivot_table(
            index="date", columns="category",
            values="duration_minutes", aggfunc="sum", fill_value=0
        ).reset_index()

        cats = [c for c in pivot.columns if c != "date"]
        fig2 = go.Figure()
        for cat in cats:
            fig2.add_trace(go.Bar(
                x=pivot["date"], y=pivot[cat] / 60,
                name=cat, marker_color=COLOR_MAP.get(cat, "#888")
            ))
        fig2.update_layout(barmode="stack", template="simple_white",
                           height=320, yaxis_title="Hours",
                           legend=dict(orientation="h", yanchor="bottom", y=1.02))
        st.plotly_chart(fig2, use_container_width=True)

    # Patterns
    if not patterns.empty:
        st.subheader("Detected Behaviour Patterns")
        pattern_counts = (
            patterns["patterns"]
            .str.split(", ")
            .explode()
            .value_counts()
            .reset_index()
        )
        pattern_counts.columns = ["pattern", "days_detected"]
        pattern_counts = pattern_counts[pattern_counts["pattern"] != "normal"]

        if not pattern_counts.empty:
            fig3 = px.bar(pattern_counts, x="days_detected", y="pattern",
                          orientation="h", template="simple_white",
                          color_discrete_sequence=["#D85A30"])
            fig3.update_layout(height=280, yaxis_title="")
            st.plotly_chart(fig3, use_container_width=True)
        else:
            st.info("No concerning patterns detected — great habits!")

    # Heatmap: screen time by day of week
    if not day_summary.empty:
        st.subheader("Screen Time by Day of Week")
        day_summary["dow"] = pd.to_datetime(day_summary["date"]).dt.day_name()
        dow_avg = (
            day_summary.groupby("dow")["total_screen_time_hours"]
            .mean().round(2).reset_index()
        )
        order = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
        dow_avg["dow"] = pd.Categorical(dow_avg["dow"], categories=order, ordered=True)
        dow_avg = dow_avg.sort_values("dow")
        fig4 = px.bar(dow_avg, x="dow", y="total_screen_time_hours",
                      color="total_screen_time_hours",
                      color_continuous_scale=["#E1F5EE","#D85A30"],
                      template="simple_white", labels={"dow":"","total_screen_time_hours":"Avg hrs"})
        fig4.update_layout(height=260, showlegend=False)
        st.plotly_chart(fig4, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# PAGE: ML PREDICTIONS
# ══════════════════════════════════════════════════════════════════════════════
elif page == "🤖 ML Predictions":
    st.header("🤖 ML Usage Predictions")

    if predictions.empty:
        st.warning("No predictions found. Run the pipeline first.")
        st.stop()

    predictions["forecast_date"] = pd.to_datetime(predictions["forecast_date"])

    # Daily predicted total
    daily_pred = (
        predictions.groupby(["forecast_date", "productivity_label"])["predicted_minutes"]
        .sum().reset_index()
    )

    st.subheader("Predicted Daily Screen Time (Next 7 Days)")
    fig = px.bar(
        daily_pred, x="forecast_date", y="predicted_minutes",
        color="productivity_label",
        color_discrete_map={
            "Productive":   "#1D9E75",
            "Neutral":      "#BA7517",
            "Unproductive": "#D85A30",
        },
        labels={"predicted_minutes": "Predicted Minutes", "forecast_date": "Date"},
        template="simple_white"
    )
    fig.update_layout(height=300, barmode="stack",
                      legend=dict(orientation="h", yanchor="bottom", y=1.02))
    st.plotly_chart(fig, use_container_width=True)

    # Per-app predictions table
    st.subheader("Per-App Predictions")
    pred_table = (
        predictions.groupby(["app_name", "category", "productivity_label"])["predicted_minutes"]
        .sum().reset_index()
        .sort_values("predicted_minutes", ascending=False)
        .head(15)
    )
    pred_table["predicted_hours"] = (pred_table["predicted_minutes"] / 60).round(2)
    pred_table["confidence"] = predictions.groupby("app_name")["confidence"].mean().reindex(pred_table["app_name"]).values
    pred_table["confidence"] = pred_table["confidence"].round(1).astype(str) + "%"

    st.dataframe(
        pred_table[["app_name","category","productivity_label","predicted_hours","confidence"]],
        use_container_width=True, hide_index=True
    )

    # Productivity score prediction
    st.subheader("Predicted Productivity Score (Tomorrow)")
    tomorrow = predictions["forecast_date"].min()
    tom = predictions[predictions["forecast_date"] == tomorrow]
    if not tom.empty:
        total = tom["predicted_minutes"].sum()
        prod  = tom[tom["productivity_label"]=="Productive"]["predicted_minutes"].sum()
        score = round(prod / total * 100, 1) if total > 0 else 0

        col1, col2 = st.columns([1, 3])
        with col1:
            color = "#1D9E75" if score >= 60 else "#BA7517" if score >= 40 else "#D85A30"
            st.markdown(f"""
            <div style="text-align:center;padding:20px;background:#f9f9f7;border-radius:12px;border:1px solid #e0e0da;">
              <div style="font-size:48px;font-weight:700;color:{color};">{score}%</div>
              <div style="color:#888;font-size:13px;margin-top:4px;">predicted productivity</div>
            </div>
            """, unsafe_allow_html=True)
        with col2:
            st.info(f"Tomorrow ({tomorrow.strftime('%A, %b %d')}): "
                    f"predicted {score}% productivity score. "
                    f"Total predicted screen time: {round(total/60,1)}h. "
                    f"{'Consider enabling Focus Mode in the evening.' if score < 60 else 'Great pattern predicted — keep it up!'}")


# ══════════════════════════════════════════════════════════════════════════════
# PAGE: ALERTS
# ══════════════════════════════════════════════════════════════════════════════
elif page == "🔔 Alerts":
    st.header("🔔 Alerts & Recommendations")

    if not alerts:
        st.success("No alerts. Your usage looks healthy!")
        st.stop()

    sev_order = {"critical":0,"high":1,"medium":2,"low":3,"info":4}
    alerts_sorted = sorted(alerts, key=lambda a: sev_order.get(a.get("severity","info"), 4))

    sev_colors = {
        "critical": "#993C1D",
        "high":     "#D85A30",
        "medium":   "#BA7517",
        "low":      "#1D9E75",
        "info":     "#185FA5",
    }

    # Summary metrics
    c1, c2, c3, c4 = st.columns(4)
    counts = {s: sum(1 for a in alerts if a.get("severity") == s) for s in sev_order}
    with c1: st.metric("Critical",  counts.get("critical", 0))
    with c2: st.metric("High",      counts.get("high", 0))
    with c3: st.metric("Medium",    counts.get("medium", 0))
    with c4: st.metric("Info",      counts.get("info", 0))

    st.markdown("---")

    # Filter
    sev_filter = st.multiselect("Filter by severity",
        ["critical","high","medium","low","info"],
        default=["critical","high","medium"]
    )

    for alert in alerts_sorted:
        sev = alert.get("severity", "info")
        if sev not in sev_filter:
            continue

        color = sev_colors.get(sev, "#888")
        with st.container():
            st.markdown(f"""
            <div style="border-left:4px solid {color};padding:12px 16px;
                        background:#fafaf8;border-radius:0 8px 8px 0;margin-bottom:10px;">
              <div style="font-weight:600;font-size:14px;color:{color};">
                [{sev.upper()}] {alert.get('title','')}
              </div>
              <div style="font-size:13px;color:#444;margin-top:4px;">{alert.get('message','')}</div>
              <div style="font-size:12px;color:#888;margin-top:4px;">
                💡 {alert.get('action','')} &nbsp;·&nbsp; {alert.get('date','')}
                {' &nbsp;·&nbsp; App: '+alert['app_name'] if alert.get('app_name') else ''}
              </div>
            </div>
            """, unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# PAGE: DATASET
# ══════════════════════════════════════════════════════════════════════════════
elif page == "📁 Dataset":
    st.header("📁 Processed Dataset")

    tabs = st.tabs(["Sessions", "App Daily", "Day Summary", "Weekly", "Predictions"])

    with tabs[0]:
        st.subheader(f"Session Data ({len(sessions):,} rows)")
        if not sessions.empty:
            cols_show = ["user_id","date","app_name","category","productivity_label",
                         "duration_minutes","session_score","time_of_day","day_of_week"]
            st.dataframe(sessions[[c for c in cols_show if c in sessions.columns]].head(500),
                         use_container_width=True, hide_index=True)

    with tabs[1]:
        st.subheader(f"App Daily Summary ({len(app_daily):,} rows)")
        st.dataframe(app_daily.head(500), use_container_width=True, hide_index=True)

    with tabs[2]:
        st.subheader(f"Day Summary ({len(day_summary):,} rows)")
        st.dataframe(day_summary.head(200), use_container_width=True, hide_index=True)

    with tabs[3]:
        st.subheader(f"Weekly Summary ({len(weekly):,} rows)")
        st.dataframe(weekly, use_container_width=True, hide_index=True)

    with tabs[4]:
        st.subheader(f"ML Predictions ({len(predictions):,} rows)")
        if not predictions.empty:
            st.dataframe(predictions.head(200), use_container_width=True, hide_index=True)
        else:
            st.info("No predictions yet.")

    # Download
    st.markdown("---")
    dataset_path = os.path.join(DATA_DIR, "processed_usage_dataset.csv")
    if os.path.exists(dataset_path):
        with open(dataset_path, "rb") as f:
            st.download_button(
                "⬇️ Download Processed Dataset (CSV)",
                data=f,
                file_name="processed_usage_dataset.csv",
                mime="text/csv",
            )
