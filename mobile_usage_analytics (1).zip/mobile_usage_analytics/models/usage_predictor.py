"""
models/usage_predictor.py
--------------------------
Predicts next-day app usage duration using multiple ML approaches:

  1. Weighted Moving Average (WMA)       — fast, no training required
  2. Random Forest Regressor             — captures non-linear patterns
  3. Linear Regression with day features — interpretable baseline
  4. Ensemble: weighted average of all three

Predictions are generated per (user, app) for the next N days.
"""

import pandas as pd
import numpy as np
import os
import logging
import joblib
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import cross_val_score
from sklearn.metrics import mean_absolute_error
from datetime import datetime, timedelta

log = logging.getLogger(__name__)

MODEL_PATH = "data/models"


# ── Feature Engineering ────────────────────────────────────────────────────────

def build_features(app_daily: pd.DataFrame) -> pd.DataFrame:
    """
    Build feature matrix for ML prediction.
    Each row = (user, app, date) with lag features and date features.
    """
    df = app_daily.copy()
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values(["user_id", "app_name", "date"])

    # Encode categorical
    le_app = LabelEncoder()
    le_cat = LabelEncoder()
    df["app_encoded"] = le_app.fit_transform(df["app_name"])
    df["cat_encoded"] = le_cat.fit_transform(df["category"])

    # Date features
    df["day_of_week"]  = df["date"].dt.dayofweek        # 0=Mon, 6=Sun
    df["is_weekend"]   = (df["day_of_week"] >= 5).astype(int)
    df["month"]        = df["date"].dt.month
    df["week_of_year"] = df["date"].dt.isocalendar().week.astype(int)

    # Lag features per (user, app)
    grp = df.groupby(["user_id", "app_name"])["total_duration_minutes"]
    for lag in [1, 2, 3, 7]:
        df[f"lag_{lag}d"] = grp.shift(lag)

    # Rolling features
    df["roll_7d_mean"] = grp.transform(lambda x: x.rolling(7, min_periods=1).mean())
    df["roll_7d_std"]  = grp.transform(lambda x: x.rolling(7, min_periods=1).std().fillna(0))
    df["roll_3d_mean"] = grp.transform(lambda x: x.rolling(3, min_periods=1).mean())

    # Same-day-of-week historical mean
    df["dow_mean"] = (
        df.groupby(["user_id", "app_name", "day_of_week"])["total_duration_minutes"]
        .transform("mean")
        .round(2)
    )

    df = df.dropna(subset=["lag_1d", "lag_7d"])
    return df, le_app, le_cat


FEATURE_COLS = [
    "app_encoded", "cat_encoded",
    "day_of_week", "is_weekend", "month", "week_of_year",
    "lag_1d", "lag_2d", "lag_3d", "lag_7d",
    "roll_7d_mean", "roll_7d_std", "roll_3d_mean", "dow_mean",
]
TARGET_COL = "total_duration_minutes"


# ── Weighted Moving Average ────────────────────────────────────────────────────

def wma_predict(series: pd.Series, weights=(0.4, 0.3, 0.2, 0.1)) -> float:
    """Weighted moving average of the last len(weights) values."""
    recent = series.dropna().tail(len(weights)).values
    if len(recent) == 0:
        return 0.0
    w = np.array(weights[:len(recent)])
    w = w[::-1] / w[::-1].sum()  # reverse so most recent has highest weight
    return float(np.dot(recent, w))


def wma_forecast(app_daily: pd.DataFrame, forecast_days: int = 7) -> pd.DataFrame:
    """WMA forecast for all (user, app) pairs."""
    records = []
    app_daily["date"] = pd.to_datetime(app_daily["date"])
    last_date = app_daily["date"].max()

    for (uid, app), grp in app_daily.groupby(["user_id", "app_name"]):
        grp = grp.sort_values("date")
        series = grp.set_index("date")["total_duration_minutes"]
        cat = grp["category"].iloc[-1]
        prod_label = grp["productivity_label"].iloc[-1]

        for d in range(1, forecast_days + 1):
            target_date = last_date + timedelta(days=d)
            pred = wma_predict(series)
            # apply day-of-week multiplier
            dow = target_date.weekday()
            if dow >= 5 and prod_label == "Unproductive":
                pred *= 1.3
            elif dow >= 5 and prod_label == "Productive":
                pred *= 0.7

            records.append({
                "user_id":           uid,
                "app_name":          app,
                "category":          cat,
                "productivity_label":prod_label,
                "forecast_date":     target_date.strftime("%Y-%m-%d"),
                "predicted_minutes": round(max(0, pred), 2),
                "model":             "WMA",
                "confidence":        min(95, 60 + len(series) * 1.5),
            })
            # Extend series with prediction for multi-step
            series[target_date] = pred

    return pd.DataFrame(records)


# ── Random Forest ──────────────────────────────────────────────────────────────

class RFPredictor:
    def __init__(self):
        self.model = GradientBoostingRegressor(
            n_estimators=200, max_depth=5, learning_rate=0.05,
            subsample=0.8, random_state=42
        )
        self.le_app = None
        self.le_cat = None
        self.is_trained = False

    def train(self, app_daily: pd.DataFrame) -> dict:
        features_df, self.le_app, self.le_cat = build_features(app_daily)

        train_df = features_df.dropna(subset=FEATURE_COLS)
        X = train_df[FEATURE_COLS].values
        y = train_df[TARGET_COL].values

        if len(X) < 20:
            log.warning("Insufficient data for RF training (< 20 samples).")
            return {"mae": None, "cv_mae": None}

        self.model.fit(X, y)
        self.is_trained = True

        preds = self.model.predict(X)
        mae   = mean_absolute_error(y, preds)

        scores = cross_val_score(
            self.model, X, y,
            cv=min(5, len(X) // 5),
            scoring="neg_mean_absolute_error"
        )
        cv_mae = -scores.mean()

        log.info(f"RF Trained — MAE: {mae:.2f} min | CV MAE: {cv_mae:.2f} min")

        os.makedirs(MODEL_PATH, exist_ok=True)
        joblib.dump(self, os.path.join(MODEL_PATH, "rf_predictor.pkl"))

        return {"mae": round(mae, 2), "cv_mae": round(cv_mae, 2)}

    def predict_next_days(self, app_daily: pd.DataFrame, forecast_days: int = 7) -> pd.DataFrame:
        if not self.is_trained:
            log.warning("RF model not trained. Run .train() first.")
            return pd.DataFrame()

        features_df, _, _ = build_features(app_daily)
        records = []
        last_date = pd.to_datetime(app_daily["date"]).max()

        for (uid, app), grp in features_df.groupby(["user_id", "app_name"]):
            grp = grp.sort_values("date")
            if len(grp) < 5:
                continue

            last_row = grp.iloc[-1].copy()
            cat = last_row["category"]
            prod_label = grp["productivity_label"].iloc[-1]

            rolling_history = list(grp["total_duration_minutes"].tail(14).values)

            for d in range(1, forecast_days + 1):
                target_date = last_date + timedelta(days=d)
                feat = last_row.copy()
                feat["day_of_week"]  = target_date.dayofweek
                feat["is_weekend"]   = int(target_date.dayofweek >= 5)
                feat["month"]        = target_date.month
                feat["week_of_year"] = target_date.isocalendar()[1]

                # Update lag features
                if len(rolling_history) >= 1: feat["lag_1d"] = rolling_history[-1]
                if len(rolling_history) >= 2: feat["lag_2d"] = rolling_history[-2]
                if len(rolling_history) >= 3: feat["lag_3d"] = rolling_history[-3]
                if len(rolling_history) >= 7: feat["lag_7d"] = rolling_history[-7]
                feat["roll_7d_mean"] = np.mean(rolling_history[-7:])
                feat["roll_7d_std"]  = np.std(rolling_history[-7:])
                feat["roll_3d_mean"] = np.mean(rolling_history[-3:])

                X_pred = np.array([[feat.get(c, 0) for c in FEATURE_COLS]])
                pred = float(self.model.predict(X_pred)[0])
                pred = max(0, pred)

                records.append({
                    "user_id":           uid,
                    "app_name":          app,
                    "category":          cat,
                    "productivity_label":prod_label,
                    "forecast_date":     target_date.strftime("%Y-%m-%d"),
                    "predicted_minutes": round(pred, 2),
                    "model":             "GradientBoosting",
                    "confidence":        round(min(95, 70 + len(grp) * 0.5), 1),
                })
                rolling_history.append(pred)

        return pd.DataFrame(records)


# ── Ensemble ───────────────────────────────────────────────────────────────────

def ensemble_forecast(wma_df: pd.DataFrame, rf_df: pd.DataFrame,
                       w_wma: float = 0.4, w_rf: float = 0.6) -> pd.DataFrame:
    """
    Merge WMA and RF predictions and produce a weighted ensemble.
    """
    key = ["user_id", "app_name", "forecast_date"]

    wma_df = wma_df.rename(columns={"predicted_minutes": "pred_wma"})[key + ["pred_wma", "category", "productivity_label"]]
    rf_df  = rf_df.rename(columns={"predicted_minutes": "pred_rf"})[key + ["pred_rf"]]

    merged = wma_df.merge(rf_df, on=key, how="outer")
    merged["pred_wma"] = merged["pred_wma"].fillna(0)
    merged["pred_rf"]  = merged["pred_rf"].fillna(0)

    merged["predicted_minutes"] = (
        w_wma * merged["pred_wma"] + w_rf * merged["pred_rf"]
    ).round(2)
    merged["model"] = "Ensemble"

    # Confidence: average of individual, capped at 95
    merged["confidence"] = np.clip(
        (0.4 * 75 + 0.6 * 80), 0, 95
    )

    return merged[key + ["category", "productivity_label", "predicted_minutes", "model", "confidence"]]


# ── Master runner ──────────────────────────────────────────────────────────────

def run_prediction(app_daily: pd.DataFrame, forecast_days: int = 7,
                   output_dir: str = "data") -> dict:
    """Train models and generate forecasts. Saves predictions CSV."""
    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(MODEL_PATH, exist_ok=True)

    log.info("Running WMA forecast...")
    wma_preds = wma_forecast(app_daily, forecast_days)

    log.info("Training & running Gradient Boosting forecast...")
    rf = RFPredictor()
    metrics = rf.train(app_daily)
    rf_preds = rf.predict_next_days(app_daily, forecast_days)

    log.info("Building ensemble...")
    if not rf_preds.empty:
        final_preds = ensemble_forecast(wma_preds, rf_preds)
    else:
        final_preds = wma_preds.copy()
        final_preds["model"] = "WMA_only"

    out_path = os.path.join(output_dir, "predictions.csv")
    final_preds.to_csv(out_path, index=False)
    log.info(f"Predictions saved: {out_path} ({len(final_preds):,} rows)")

    # Daily predicted productivity score
    pred_summary = (
        final_preds.groupby("forecast_date")
        .apply(lambda g: np.average(
            g["predicted_minutes"],
            weights=g["predicted_minutes"].replace(0, 0.01)
        ))
        .reset_index(name="avg_predicted_minutes")
    )

    return {
        "predictions":   final_preds,
        "pred_summary":  pred_summary,
        "model_metrics": metrics,
    }


if __name__ == "__main__":
    app_daily = pd.read_csv("data/app_daily_summary.csv")
    results   = run_prediction(app_daily)
    print(results["predictions"].head(20).to_string())
    print(f"\nModel metrics: {results['model_metrics']}")
