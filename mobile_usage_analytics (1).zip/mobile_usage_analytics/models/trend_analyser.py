"""
models/trend_analyser.py
------------------------
Computes trend statistics, detects anomalies, and flags behaviour patterns.

Key outputs:
  - Rolling 7-day averages
  - Week-over-week deltas
  - Anomaly flags (z-score based)
  - Pattern tags (e.g. "Late night gaming", "Weekend binge")
"""

import pandas as pd
import numpy as np
import logging
import os

log = logging.getLogger(__name__)


# ── Rolling Trends ─────────────────────────────────────────────────────────────

def compute_rolling_averages(day_df: pd.DataFrame, windows=(3, 7, 14)) -> pd.DataFrame:
    """
    Add rolling mean columns for screen time and productivity per user.
    day_df must have columns: user_id, date, total_screen_time_minutes, productivity_pct
    """
    df = day_df.copy()
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values(["user_id", "date"])

    for w in windows:
        df[f"rolling_{w}d_screen_time"] = (
            df.groupby("user_id")["total_screen_time_minutes"]
            .transform(lambda x: x.rolling(w, min_periods=1).mean())
            .round(2)
        )
        df[f"rolling_{w}d_productivity"] = (
            df.groupby("user_id")["productivity_pct"]
            .transform(lambda x: x.rolling(w, min_periods=1).mean())
            .round(2)
        )

    return df


def compute_wow_delta(day_df: pd.DataFrame) -> pd.DataFrame:
    """
    Week-over-week change in screen time and productivity.
    Adds delta columns for comparing each week to the previous.
    """
    df = day_df.copy()
    df["date"] = pd.to_datetime(df["date"])

    weekly = (
        df.groupby(["user_id", pd.Grouper(key="date", freq="W")])
        .agg(
            avg_screen_time=("total_screen_time_minutes", "mean"),
            avg_productivity=("productivity_pct", "mean"),
        )
        .reset_index()
    )
    weekly = weekly.sort_values(["user_id", "date"])
    weekly["wow_screen_delta"]      = weekly.groupby("user_id")["avg_screen_time"].diff().round(2)
    weekly["wow_productivity_delta"]= weekly.groupby("user_id")["avg_productivity"].diff().round(2)
    return weekly


# ── Anomaly Detection ──────────────────────────────────────────────────────────

def detect_anomalies(day_df: pd.DataFrame, z_threshold: float = 2.0) -> pd.DataFrame:
    """
    Flag days where screen time or productivity deviate beyond z_threshold
    standard deviations from the user's personal mean.
    """
    df = day_df.copy()

    def zscore(series):
        mu, sigma = series.mean(), series.std()
        return (series - mu) / sigma if sigma > 0 else pd.Series([0.0] * len(series), index=series.index)

    df["screen_time_zscore"] = (
        df.groupby("user_id")["total_screen_time_minutes"]
        .transform(zscore)
        .round(3)
    )
    df["productivity_zscore"] = (
        df.groupby("user_id")["productivity_pct"]
        .transform(zscore)
        .round(3)
    )

    df["is_high_usage_day"]     = df["screen_time_zscore"]  >  z_threshold
    df["is_low_usage_day"]      = df["screen_time_zscore"]  < -z_threshold
    df["is_low_productivity_day"]= df["productivity_zscore"] < -z_threshold
    df["is_high_productivity_day"]= df["productivity_zscore"] >  z_threshold

    return df


# ── Pattern Detection ──────────────────────────────────────────────────────────

def detect_patterns(session_df: pd.DataFrame) -> pd.DataFrame:
    """
    Detect per-day behavioural patterns from session data.

    Patterns flagged:
      - late_night_usage       : any session after 11 PM for unproductive apps
      - morning_productivity   : productive app used before 9 AM
      - weekend_binge          : weekend day with >5 hrs unproductive
      - continuous_gaming      : single gaming session > 90 mins
      - social_media_spiral    : social media > 3 hrs in a day
      - study_streak           : education > 2 hrs in a day
    """
    df = session_df.copy()
    df["start_time"] = pd.to_datetime(df["start_time"])
    df["hour"] = df["start_time"].dt.hour

    records = []
    for (uid, date), grp in df.groupby(["user_id", "date"]):
        patterns = []

        # Late-night unproductive
        late = grp[(grp["is_unproductive"]) & (grp["hour"] >= 23)]
        if not late.empty:
            patterns.append("late_night_usage")

        # Morning productivity
        morning_prod = grp[(grp["is_productive"]) & (grp["hour"] < 9)]
        if not morning_prod.empty:
            patterns.append("morning_productivity")

        # Weekend binge
        if grp["is_weekend"].any():
            unp_mins = grp.loc[grp["is_unproductive"], "duration_minutes"].sum()
            if unp_mins > 300:
                patterns.append("weekend_binge")

        # Continuous gaming
        gaming = grp[grp["category"] == "Gaming"]
        if not gaming.empty and gaming["duration_minutes"].max() > 90:
            patterns.append("continuous_gaming")

        # Social media spiral
        sm_mins = grp.loc[grp["category"] == "Social Media", "duration_minutes"].sum()
        if sm_mins > 180:
            patterns.append("social_media_spiral")

        # Study streak
        edu_mins = grp.loc[grp["category"] == "Education", "duration_minutes"].sum()
        if edu_mins > 120:
            patterns.append("study_streak")

        records.append({
            "user_id":  uid,
            "date":     date,
            "patterns": ", ".join(patterns) if patterns else "normal",
            "pattern_count": len(patterns),
        })

    return pd.DataFrame(records)


# ── Category Trend ─────────────────────────────────────────────────────────────

def category_trend(session_df: pd.DataFrame) -> pd.DataFrame:
    """
    Daily minutes per category per user — useful for stacked time series.
    """
    return (
        session_df.groupby(["user_id", "date", "category"])["duration_minutes"]
        .sum()
        .round(2)
        .reset_index()
    )


# ── Master runner ──────────────────────────────────────────────────────────────

def run_trend_analysis(session_df: pd.DataFrame, day_df: pd.DataFrame,
                       output_dir: str = "data") -> dict:
    """Run all trend analyses and save outputs."""
    os.makedirs(output_dir, exist_ok=True)

    df_rolling   = compute_rolling_averages(day_df)
    df_wow       = compute_wow_delta(day_df)
    df_anomaly   = detect_anomalies(day_df)
    df_patterns  = detect_patterns(session_df)
    df_cat_trend = category_trend(session_df)

    outputs = {
        "rolling":   df_rolling,
        "wow":       df_wow,
        "anomalies": df_anomaly,
        "patterns":  df_patterns,
        "cat_trend": df_cat_trend,
    }

    for name, df in outputs.items():
        path = os.path.join(output_dir, f"trend_{name}.csv")
        df.to_csv(path, index=False)
        log.info(f"Saved trend output '{name}': {path}")

    return outputs


if __name__ == "__main__":
    session_df = pd.read_csv("data/processed_sessions.csv")
    day_df     = pd.read_csv("data/daily_summary.csv")
    results    = run_trend_analysis(session_df, day_df)
    for k, v in results.items():
        print(f"  {k:12s}: {v.shape}")
