"""
generate_sample_data.py
-----------------------
Generates realistic synthetic mobile app usage logs for 30 days.
Output: data/raw_usage_logs.csv

Each row = one app session with:
  - user_id, date, app_name, start_time, end_time, duration_seconds
"""

import pandas as pd
import numpy as np
import os
from datetime import datetime, timedelta
import random

random.seed(42)
np.random.seed(42)

# ── App definitions ────────────────────────────────────────────────────────────
APPS = {
    # name: (category, base_daily_sessions, avg_session_mins, std_session_mins)
    "Instagram":      ("Social Media",   8, 15, 8),
    "YouTube":        ("Entertainment",  4, 18, 12),
    "Mobile Legends": ("Gaming",         3, 28, 15),
    "WhatsApp":       ("Communication",  12, 5, 3),
    "Khan Academy":   ("Education",      2, 25, 10),
    "Notion":         ("Productivity",   3, 20, 8),
    "Google Chrome":  ("Utility",        6, 8,  5),
    "Duolingo":       ("Education",      1, 15, 5),
    "TikTok":         ("Social Media",   5, 12, 7),
    "Gmail":          ("Communication",  4, 6,  3),
    "Google Maps":    ("Utility",        2, 5,  2),
    "Netflix":        ("Entertainment",  2, 45, 20),
    "Spotify":        ("Entertainment",  3, 30, 15),
    "Coursera":       ("Education",      1, 35, 10),
    "Google Docs":    ("Productivity",   2, 22, 8),
    "Twitter":        ("Social Media",   3, 10, 5),
    "PUBG Mobile":    ("Gaming",         2, 20, 10),
    "Camera":         ("Utility",        4, 3,  2),
    "Calendar":       ("Productivity",   2, 4,  2),
    "Snapchat":       ("Social Media",   3, 8,  4),
}

# Weekend multipliers per category
WEEKEND_MULT = {
    "Social Media": 1.5,
    "Gaming":       1.8,
    "Entertainment":1.4,
    "Education":    0.6,
    "Productivity": 0.4,
    "Communication":1.1,
    "Utility":      0.9,
}

# Evening (6 PM–11 PM) usage spike multiplier
EVENING_APPS = {"Instagram","YouTube","Mobile Legends","TikTok","Netflix","PUBG Mobile","Snapchat"}


def random_time(date, hour_start=7, hour_end=23):
    """Return a random datetime within waking hours of a given date."""
    hour = random.randint(hour_start, hour_end - 1)
    minute = random.randint(0, 59)
    second = random.randint(0, 59)
    return datetime(date.year, date.month, date.day, hour, minute, second)


def generate_sessions(app_name, meta, date, user_id):
    """Generate all sessions for one app on one date."""
    category, base_sessions, avg_mins, std_mins = meta
    rows = []

    is_weekend = date.weekday() >= 5
    mult = WEEKEND_MULT.get(category, 1.0) if is_weekend else 1.0

    n_sessions = max(0, int(np.random.poisson(base_sessions * mult)))

    for _ in range(n_sessions):
        # Bias evening apps toward evening hours
        if app_name in EVENING_APPS and random.random() < 0.6:
            start = random_time(date, hour_start=18, hour_end=23)
        else:
            start = random_time(date)

        dur_mins = max(1, np.random.normal(avg_mins, std_mins))
        dur_secs = int(dur_mins * 60)
        end = start + timedelta(seconds=dur_secs)

        rows.append({
            "user_id":          user_id,
            "date":             date.strftime("%Y-%m-%d"),
            "app_name":         app_name,
            "category":         category,
            "start_time":       start.strftime("%Y-%m-%d %H:%M:%S"),
            "end_time":         end.strftime("%Y-%m-%d %H:%M:%S"),
            "duration_seconds": dur_secs,
        })
    return rows


def generate(days=30, n_users=1, output_path="data/raw_usage_logs.csv"):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    all_rows = []
    end_date = datetime.today().date()
    start_date = end_date - timedelta(days=days - 1)

    for user_id in range(1, n_users + 1):
        uid = f"user_{user_id:03d}"
        current = start_date
        while current <= end_date:
            for app_name, meta in APPS.items():
                # ~20% chance app not used on any given day
                if random.random() < 0.2:
                    continue
                rows = generate_sessions(app_name, meta, current, uid)
                all_rows.extend(rows)
            current += timedelta(days=1)

    df = pd.DataFrame(all_rows)
    df.sort_values(["user_id", "start_time"], inplace=True)
    df.reset_index(drop=True, inplace=True)
    df.to_csv(output_path, index=False)
    print(f"[generate_sample_data] Generated {len(df):,} sessions for {n_users} user(s) over {days} days.")
    print(f"[generate_sample_data] Saved to: {output_path}")
    return df


if __name__ == "__main__":
    generate(days=30, n_users=1)
