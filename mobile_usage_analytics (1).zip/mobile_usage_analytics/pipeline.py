"""
pipeline.py
-----------
End-to-end orchestrator for the Mobile Behaviour Usage Analytics system.

Steps:
  1. Generate sample data (if raw data doesn't exist)
  2. Preprocess & enrich sessions
  3. Run trend analysis
  4. Train ML model & generate predictions
  5. Run notification engine
  6. Generate HTML reports & export processed dataset
"""

import os
import sys
import logging
import pandas as pd
from datetime import datetime

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger(__name__)

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

RAW_DATA_PATH = "data/raw_usage_logs.csv"
DATA_DIR      = "data"


def step(n, name):
    log.info(f"\n{'='*60}")
    log.info(f"  STEP {n}: {name}")
    log.info(f"{'='*60}")


def run_pipeline(skip_data_gen: bool = False,
                 forecast_days: int = 7) -> dict:

    start = datetime.now()
    results = {}

    # ── Step 1: Generate sample data ──────────────────────────────────────────
    step(1, "Data Ingestion")
    if not os.path.exists(RAW_DATA_PATH) and not skip_data_gen:
        log.info("Raw data not found. Generating sample data...")
        from sample_data.generate_sample_data import generate
        generate(days=30, n_users=1, output_path=RAW_DATA_PATH)
    else:
        log.info(f"Using existing raw data: {RAW_DATA_PATH}")

    # ── Step 2: Preprocess ────────────────────────────────────────────────────
    step(2, "Preprocessing & Enrichment")
    from utils.preprocessor import run_preprocessing
    preprocessed = run_preprocessing(RAW_DATA_PATH, DATA_DIR)

    session_df  = preprocessed["sessions"]
    app_daily   = preprocessed["app_daily"]
    day_summary = preprocessed["day_summary"]
    weekly_df   = preprocessed["weekly"]

    log.info(f"Sessions:     {len(session_df):,} rows")
    log.info(f"App-daily:    {len(app_daily):,} rows")
    log.info(f"Day summary:  {len(day_summary):,} rows")

    results["preprocessed"] = preprocessed

    # ── Step 3: Trend Analysis ────────────────────────────────────────────────
    step(3, "Trend Analysis")
    from models.trend_analyser import run_trend_analysis
    trends = run_trend_analysis(session_df, day_summary, DATA_DIR)

    log.info(f"Patterns detected: {len(trends['patterns'])} day-pattern records")
    log.info(f"Anomalies flagged: {trends['anomalies']['is_high_usage_day'].sum()} high-usage days")

    results["trends"] = trends

    # ── Step 4: ML Prediction ─────────────────────────────────────────────────
    step(4, "ML Prediction")
    from models.usage_predictor import run_prediction
    pred_results = run_prediction(app_daily, forecast_days=forecast_days,
                                   output_dir=DATA_DIR)

    predictions = pred_results["predictions"]
    log.info(f"Predictions generated: {len(predictions):,} rows ({forecast_days} days ahead)")
    if pred_results["model_metrics"].get("mae"):
        log.info(f"Model MAE: {pred_results['model_metrics']['mae']} min")

    results["predictions"] = pred_results

    # ── Step 5: Notifications ─────────────────────────────────────────────────
    step(5, "Notification Engine")
    from reports.notification_engine import run_notifications
    alerts = run_notifications(
        session_df, app_daily, day_summary, weekly_df,
        predictions if not predictions.empty else None,
        output_dir=DATA_DIR
    )

    log.info(f"Total alerts: {len(alerts)}")
    results["alerts"] = alerts

    # ── Step 6: Reports ───────────────────────────────────────────────────────
    step(6, "Report Generation")
    from reports.report_generator import run_reports
    report_paths = run_reports(
        day_summary, app_daily, session_df, alerts, output_dir=DATA_DIR
    )
    results["reports"] = report_paths

    # ── Summary ───────────────────────────────────────────────────────────────
    elapsed = (datetime.now() - start).total_seconds()
    log.info(f"\n{'='*60}")
    log.info(f"  PIPELINE COMPLETE in {elapsed:.1f}s")
    log.info(f"{'='*60}")
    log.info(f"\nOutputs in '{DATA_DIR}/':")
    for name, path in report_paths.items():
        log.info(f"  {name:20s}: {path}")

    log.info(f"\nKey stats:")
    log.info(f"  Total sessions processed : {len(session_df):,}")
    log.info(f"  Unique apps tracked      : {session_df['app_name'].nunique()}")
    log.info(f"  Days of data             : {day_summary['date'].nunique()}")
    log.info(f"  Predictions (days ahead) : {forecast_days}")
    log.info(f"  Alerts generated         : {len(alerts)}")

    return results


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Mobile Usage Analytics Pipeline")
    parser.add_argument("--skip-data-gen", action="store_true",
                        help="Skip sample data generation (use existing raw CSV)")
    parser.add_argument("--forecast-days", type=int, default=7,
                        help="Number of days to forecast (default: 7)")
    args = parser.parse_args()

    run_pipeline(
        skip_data_gen=args.skip_data_gen,
        forecast_days=args.forecast_days,
    )
