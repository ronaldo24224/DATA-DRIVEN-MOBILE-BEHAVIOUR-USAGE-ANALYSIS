"""
utils/categoriser.py
--------------------
Handles app categorisation and productivity scoring.

Productivity score per session = weighted function of:
  - Category weight   (0–1)
  - Session duration  (penalise very long unproductive sessions)
  - Time of day       (late-night unproductive usage penalised more)
  - Daily total       (excess usage beyond limits penalised)
"""

from dataclasses import dataclass
from typing import Dict, Tuple
import pandas as pd
import numpy as np

# ── Master App Registry ────────────────────────────────────────────────────────
# (category, productivity_weight, daily_limit_minutes)
APP_REGISTRY: Dict[str, Tuple[str, float, int]] = {
    # Education — high productivity
    "Khan Academy":       ("Education",     0.95, 180),
    "Duolingo":           ("Education",     0.90, 120),
    "Coursera":           ("Education",     0.95, 180),
    "Google Classroom":   ("Education",     0.90, 180),
    "Udemy":              ("Education",     0.90, 180),
    "Photomath":          ("Education",     0.85, 60),

    # Productivity — high
    "Notion":             ("Productivity",  0.90, 240),
    "Google Docs":        ("Productivity",  0.90, 240),
    "Google Sheets":      ("Productivity",  0.88, 240),
    "Google Slides":      ("Productivity",  0.85, 180),
    "Microsoft Word":     ("Productivity",  0.90, 240),
    "Microsoft Excel":    ("Productivity",  0.88, 240),
    "Calendar":           ("Productivity",  0.80, 30),
    "Todoist":            ("Productivity",  0.85, 60),
    "Trello":             ("Productivity",  0.82, 90),
    "Slack":              ("Communication", 0.75, 120),

    # Communication — medium
    "WhatsApp":           ("Communication", 0.65, 60),
    "Gmail":              ("Communication", 0.70, 90),
    "Telegram":           ("Communication", 0.65, 60),
    "Outlook":            ("Communication", 0.70, 90),
    "Messages":           ("Communication", 0.60, 45),
    "Phone":              ("Communication", 0.60, 45),

    # Utility — medium
    "Google Chrome":      ("Utility",       0.60, 120),
    "Google Maps":        ("Utility",       0.75, 30),
    "Camera":             ("Utility",       0.65, 20),
    "Settings":           ("Utility",       0.70, 15),
    "Files":              ("Utility",       0.65, 20),
    "Calculator":         ("Utility",       0.75, 15),
    "Clock":              ("Utility",       0.70, 10),

    # Entertainment — low
    "YouTube":            ("Entertainment", 0.30, 120),
    "Netflix":            ("Entertainment", 0.20, 90),
    "Spotify":            ("Entertainment", 0.35, 120),
    "Amazon Prime":       ("Entertainment", 0.20, 90),
    "Disney+":            ("Entertainment", 0.20, 90),
    "Twitch":             ("Entertainment", 0.15, 60),

    # Social Media — low
    "Instagram":          ("Social Media",  0.15, 90),
    "TikTok":             ("Social Media",  0.10, 30),
    "Twitter":            ("Social Media",  0.20, 60),
    "Facebook":           ("Social Media",  0.15, 60),
    "Snapchat":           ("Social Media",  0.15, 45),
    "Reddit":             ("Social Media",  0.25, 60),
    "Pinterest":          ("Social Media",  0.20, 45),
    "LinkedIn":           ("Social Media",  0.55, 60),

    # Gaming — low
    "Mobile Legends":     ("Gaming",        0.10, 60),
    "PUBG Mobile":        ("Gaming",        0.10, 60),
    "Candy Crush":        ("Gaming",        0.05, 30),
    "Clash of Clans":     ("Gaming",        0.08, 45),
    "Free Fire":          ("Gaming",        0.08, 45),
    "Among Us":           ("Gaming",        0.12, 45),
    "Minecraft":          ("Gaming",        0.20, 60),  # slight creativity credit
}

# Category-level defaults for unknown apps
CATEGORY_DEFAULTS: Dict[str, Tuple[float, int]] = {
    "Education":     (0.88, 180),
    "Productivity":  (0.85, 180),
    "Communication": (0.65, 60),
    "Utility":       (0.65, 30),
    "Entertainment": (0.25, 90),
    "Social Media":  (0.15, 60),
    "Gaming":        (0.10, 60),
    "Unknown":       (0.40, 60),
}

PRODUCTIVE_CATEGORIES = {"Education", "Productivity"}
NEUTRAL_CATEGORIES    = {"Communication", "Utility"}
UNPRODUCTIVE_CATEGORIES = {"Entertainment", "Social Media", "Gaming"}


@dataclass
class AppMeta:
    category: str
    productivity_weight: float
    daily_limit_minutes: int
    is_productive: bool
    is_unproductive: bool


def get_app_meta(app_name: str) -> AppMeta:
    """Lookup or infer metadata for an app."""
    if app_name in APP_REGISTRY:
        cat, weight, limit = APP_REGISTRY[app_name]
    else:
        # Heuristic: check if any keyword matches a category
        name_lower = app_name.lower()
        if any(k in name_lower for k in ["learn", "study", "edu", "school", "course"]):
            cat = "Education"
        elif any(k in name_lower for k in ["game", "play", "clash", "legends"]):
            cat = "Gaming"
        elif any(k in name_lower for k in ["chat", "message", "mail", "meet"]):
            cat = "Communication"
        elif any(k in name_lower for k in ["social", "insta", "tik", "snap"]):
            cat = "Social Media"
        elif any(k in name_lower for k in ["tube", "flix", "stream", "music"]):
            cat = "Entertainment"
        else:
            cat = "Unknown"
        weight, limit = CATEGORY_DEFAULTS.get(cat, (0.40, 60))

    return AppMeta(
        category=cat,
        productivity_weight=weight,
        daily_limit_minutes=limit,
        is_productive=cat in PRODUCTIVE_CATEGORIES,
        is_unproductive=cat in UNPRODUCTIVE_CATEGORIES,
    )


def score_session(row: pd.Series) -> float:
    """
    Compute a 0–100 productivity score for a single session.

    Factors:
      1. Base weight from category (0–1)
      2. Duration penalty for unproductive apps > 30 min
      3. Late-night penalty (11 PM–3 AM) for unproductive apps
      4. Bonus for short, focused productive sessions
    """
    meta = get_app_meta(row["app_name"])
    base = meta.productivity_weight * 100

    dur_min = row["duration_seconds"] / 60

    # Duration modifier
    if meta.is_unproductive:
        if dur_min > 60:
            base *= 0.70
        elif dur_min > 30:
            base *= 0.85
    elif meta.is_productive:
        if 10 <= dur_min <= 45:
            base = min(100, base * 1.08)  # focused session bonus

    # Time of day modifier
    try:
        hour = pd.to_datetime(row["start_time"]).hour
        if meta.is_unproductive and (hour >= 23 or hour <= 3):
            base *= 0.75
    except Exception:
        pass

    return round(np.clip(base, 0, 100), 2)


def categorise_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Enrich a raw usage dataframe with category, productivity metadata,
    and per-session productivity score.

    Input columns required: app_name, duration_seconds, start_time
    """
    df = df.copy()

    metas = df["app_name"].apply(get_app_meta)
    df["category"]              = metas.apply(lambda m: m.category)
    df["productivity_weight"]   = metas.apply(lambda m: m.productivity_weight)
    df["daily_limit_minutes"]   = metas.apply(lambda m: m.daily_limit_minutes)
    df["is_productive"]         = metas.apply(lambda m: m.is_productive)
    df["is_unproductive"]       = metas.apply(lambda m: m.is_unproductive)
    df["session_score"]         = df.apply(score_session, axis=1)
    df["duration_minutes"]      = (df["duration_seconds"] / 60).round(2)

    # Classify label
    df["productivity_label"] = df["category"].map(
        lambda c: "Productive" if c in PRODUCTIVE_CATEGORIES
        else ("Unproductive" if c in UNPRODUCTIVE_CATEGORIES else "Neutral")
    )

    return df


def compute_daily_limits(df: pd.DataFrame) -> pd.DataFrame:
    """
    For each (user, date, app) combination, flag whether the daily limit
    was exceeded and by how many minutes.
    """
    df = df.copy()
    daily = (
        df.groupby(["user_id", "date", "app_name"])["duration_minutes"]
        .sum()
        .reset_index(name="daily_total_minutes")
    )
    daily["daily_limit_minutes"] = daily["app_name"].apply(
        lambda a: get_app_meta(a).daily_limit_minutes
    )
    daily["limit_exceeded"] = daily["daily_total_minutes"] > daily["daily_limit_minutes"]
    daily["overage_minutes"] = (
        daily["daily_total_minutes"] - daily["daily_limit_minutes"]
    ).clip(lower=0).round(2)
    return daily
