"""
utils/preprocessor.py
---------------------
Ingest, validate, clean, and aggregate raw usage logs.
Produces the core processed dataset used by all downstream modules.

Expected raw CSV columns:
  user_id, date, app_name, category, start_time, end_time, duration_seconds
"""

import pandas as pd
import numpy as np
import os
import logging
from datetime import datetime
from utils.categoriser import categorise_dataframe, compute_daily_limits, get_app_meta

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
log = logging.getLogger(__name__)


# ── Ingestion ──────────────────────────────────────────────────────────────────

def load_raw(path: str) -> pd.DataFrame:
    """Load raw usage log CSV."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"Raw data not found: {path}")
    df = pd.read_csv(path, parse_dates=["start_time", "end_time"])
    log.info(f"Loaded {len(df):,} raw sessions from {path}")
    return df


def validate(df: pd.DataFrame) -> pd.DataFrame:
    """Drop malformed rows and log issues."""
    before = len(df)

    # Required columns
    required = {"user_id", "date", "app_name", "start_time", "end_time", "duration_seconds"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    # Remove negative or zero durations
    df = df[df["duration_seconds"] > 0]

    # Remove impossibly long sessions (> 8 hours)
    df = df[df["duration_seconds"] <= 8 * 3600]

    # Remove rows where end < start
    df = df[df["end_time"] >= df["start_time"]]

    # Drop null app names
    df = df[df["app_name"].notna() & (df["app_name"].str.strip() != "")]

    after = len(df)
    if before - after:
        log.warning(f"Dropped {before - after} invalid rows during validation.")
    return df.reset_index(drop=True)


# ── Enrichment ─────────────────────────────────────────────────────────────────

def enrich(df: pd.DataFrame) -> pd.DataFrame:
    """Add category metadata, scores, and time features."""
    df = df.copy()

    # Ensure date column is string in YYYY-MM-DD
    df["date"] = pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d")

    # Time features
    df["start_time"] = pd.to_datetime(df["start_time"])
    df["hour"]       = df["start_time"].dt.hour
    df["day_of_week"]= df["start_time"].dt.day_name()
    df["is_weekend"] = df["start_time"].dt.dayofweek >= 5
    df["week_number"]= df["start_time"].dt.isocalendar().week.astype(int)
    df["month"]      = df["start_time"].dt.month

    # Time-of-day bucket
    def time_bucket(h):
        if 5 <= h < 9:   return "Morning"
        if 9 <= h < 12:  return "Midday"
        if 12 <= h < 17: return "Afternoon"
        if 17 <= h < 21: return "Evening"
        return "Night"
    df["time_of_day"] = df["hour"].apply(time_bucket)

    # Categorise & score
    df = categorise_dataframe(df)

    log.info(f"Enriched {len(df):,} sessions across {df['app_name'].nunique()} unique apps.")
    return df


# ── Aggregation ────────────────────────────────────────────────────────────────

def aggregate_daily(df: pd.DataFrame) -> pd.DataFrame:
    """
    Aggregate to daily per-user per-app summary.
    Each row = one app on one day for one user.
    """
    agg = (
        df.groupby(["user_id", "date", "app_name", "category", "productivity_label"])
        .agg(
            total_duration_minutes = ("duration_minutes", "sum"),
            session_count          = ("duration_minutes", "count"),
            avg_session_minutes    = ("duration_minutes", "mean"),
            max_session_minutes    = ("duration_minutes", "max"),
            avg_productivity_score = ("session_score",   "mean"),
            daily_limit_minutes    = ("daily_limit_minutes", "first"),
        )
        .reset_index()
    )

    agg["total_duration_minutes"] = agg["total_duration_minutes"].round(2)
    agg["avg_session_minutes"]    = agg["avg_session_minutes"].round(2)
    agg["max_session_minutes"]    = agg["max_session_minutes"].round(2)
    agg["avg_productivity_score"] = agg["avg_productivity_score"].round(2)

    # Limit exceeded flag
    agg["limit_exceeded"] = agg["total_duration_minutes"] > agg["daily_limit_minutes"]
    agg["overage_minutes"] = (
        agg["total_duration_minutes"] - agg["daily_limit_minutes"]
    ).clip(lower=0).round(2)

    return agg


def aggregate_daily_summary(df: pd.DataFrame) -> pd.DataFrame:
    """
    Aggregate to one row per (user, date) with holistic day-level metrics.
    """
    agg = (
        df.groupby(["user_id", "date", "day_of_week", "is_weekend", "week_number"])
        .agg(
            total_screen_time_minutes = ("duration_minutes", "sum"),
            total_sessions            = ("duration_minutes", "count"),
            unique_apps               = ("app_name", "nunique"),
            productive_minutes        = ("duration_minutes",
                lambda x: x[df.loc[x.index, "is_productive"]].sum()),
            unproductive_minutes      = ("duration_minutes",
                lambda x: x[df.loc[x.index, "is_unproductive"]].sum()),
            avg_session_score         = ("session_score", "mean"),
        )
        .reset_index()
    )

    agg["productivity_pct"] = (
        agg["productive_minutes"] / agg["total_screen_time_minutes"].replace(0, np.nan) * 100
    ).round(2).fillna(0)

    agg["total_screen_time_hours"] = (agg["total_screen_time_minutes"] / 60).round(2)

    # Day-level score: weighted average of session scores
    day_scores = (
        df.groupby(["user_id", "date"])
        .apply(lambda g: np.average(g["session_score"], weights=g["duration_minutes"]))
        .reset_index(name="weighted_day_score")
    )
    agg = agg.merge(day_scores, on=["user_id", "date"], how="left")
    agg["weighted_day_score"] = agg["weighted_day_score"].round(2)

    return agg


def aggregate_weekly(daily_summary: pd.DataFrame) -> pd.DataFrame:
    """Weekly rollup per user."""
    agg = (
        daily_summary.groupby(["user_id", "week_number"])
        .agg(
            avg_screen_time_hours  = ("total_screen_time_hours", "mean"),
            total_screen_time_hours= ("total_screen_time_hours", "sum"),
            avg_productive_minutes = ("productive_minutes", "mean"),
            avg_unproductive_min   = ("unproductive_minutes", "mean"),
            avg_productivity_pct   = ("productivity_pct", "mean"),
            avg_day_score          = ("weighted_day_score", "mean"),
        )
        .reset_index()
    )
    for col in ["avg_screen_time_hours","total_screen_time_hours","avg_productive_minutes",
                "avg_unproductive_min","avg_productivity_pct","avg_day_score"]:
        agg[col] = agg[col].round(2)
    return agg


# ── Top-N helpers ──────────────────────────────────────────────────────────────

def most_frequent_apps(df: pd.DataFrame, top_n: int = 10) -> pd.DataFrame:
    """Apps ranked by total session count across the dataset."""
    return (
        df.groupby(["app_name", "category", "productivity_label"])
        .agg(total_sessions=("duration_minutes", "count"),
             total_minutes =("duration_minutes", "sum"))
        .reset_index()
        .sort_values("total_sessions", ascending=False)
        .head(top_n)
        .reset_index(drop=True)
    )


def most_time_consuming_apps(df: pd.DataFrame, top_n: int = 10) -> pd.DataFrame:
    """Apps ranked by total time spent."""
    return (
        df.groupby(["app_name", "category", "productivity_label"])
        .agg(total_minutes=("duration_minutes", "sum"),
             avg_session  =("duration_minutes", "mean"))
        .reset_index()
        .sort_values("total_minutes", ascending=False)
        .head(top_n)
        .reset_index(drop=True)
    )


# ── Master pipeline ────────────────────────────────────────────────────────────

def run_preprocessing(raw_path: str, output_dir: str = "data") -> dict:
    """
    Full preprocessing pipeline.
    Returns a dict of all output DataFrames and saves CSVs to output_dir.
    """
    os.makedirs(output_dir, exist_ok=True)

    df_raw       = load_raw(raw_path)
    df_valid     = validate(df_raw)
    df_enriched  = enrich(df_valid)

    df_app_daily    = aggregate_daily(df_enriched)
    df_day_summary  = aggregate_daily_summary(df_enriched)
    df_weekly       = aggregate_weekly(df_day_summary)
    df_top_freq     = most_frequent_apps(df_enriched)
    df_top_time     = most_time_consuming_apps(df_enriched)

    # Save all outputs
    paths = {
        "sessions":     os.path.join(output_dir, "processed_sessions.csv"),
        "app_daily":    os.path.join(output_dir, "app_daily_summary.csv"),
        "day_summary":  os.path.join(output_dir, "daily_summary.csv"),
        "weekly":       os.path.join(output_dir, "weekly_summary.csv"),
        "top_frequent": os.path.join(output_dir, "top_frequent_apps.csv"),
        "top_time":     os.path.join(output_dir, "top_time_apps.csv"),
    }

    df_enriched.to_csv(paths["sessions"],    index=False)
    df_app_daily.to_csv(paths["app_daily"],  index=False)
    df_day_summary.to_csv(paths["day_summary"], index=False)
    df_weekly.to_csv(paths["weekly"],        index=False)
    df_top_freq.to_csv(paths["top_frequent"],index=False)
    df_top_time.to_csv(paths["top_time"],    index=False)

    for name, path in paths.items():
        log.info(f"Saved {name}: {path}")

    return {
        "sessions":    df_enriched,
        "app_daily":   df_app_daily,
        "day_summary": df_day_summary,
        "weekly":      df_weekly,
        "top_frequent":df_top_freq,
        "top_time":    df_top_time,
    }


if __name__ == "__main__":
    results = run_preprocessing("data/raw_usage_logs.csv")
    print("\nDataset shapes:")
    for k, v in results.items():
        print(f"  {k:15s}: {v.shape}")
