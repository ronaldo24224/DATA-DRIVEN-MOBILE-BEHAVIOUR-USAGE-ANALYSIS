"""
tests/test_pipeline.py
-----------------------
Unit and integration tests for all pipeline components.
Run with:  pytest tests/ -v
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta


# ── Fixtures ───────────────────────────────────────────────────────────────────

@pytest.fixture
def raw_sessions():
    """Minimal raw session dataframe for testing."""
    rows = []
    base = datetime(2026, 3, 1)
    apps = [
        ("Instagram",    "Social Media"),
        ("Khan Academy", "Education"),
        ("WhatsApp",     "Communication"),
        ("Mobile Legends","Gaming"),
        ("Notion",       "Productivity"),
    ]
    for day_offset in range(7):
        date = base + timedelta(days=day_offset)
        for app, cat in apps:
            for _ in range(3):
                start = date.replace(hour=np.random.randint(8, 22),
                                     minute=np.random.randint(0, 59))
                dur   = int(np.random.uniform(5, 60) * 60)
                rows.append({
                    "user_id":          "user_001",
                    "date":             date.strftime("%Y-%m-%d"),
                    "app_name":         app,
                    "category":         cat,
                    "start_time":       start.strftime("%Y-%m-%d %H:%M:%S"),
                    "end_time":         (start + timedelta(seconds=dur)).strftime("%Y-%m-%d %H:%M:%S"),
                    "duration_seconds": dur,
                })
    return pd.DataFrame(rows)


# ── Categoriser tests ──────────────────────────────────────────────────────────

class TestCategoriser:
    def test_known_app_lookup(self):
        from utils.categoriser import get_app_meta
        meta = get_app_meta("Instagram")
        assert meta.category == "Social Media"
        assert meta.is_unproductive is True
        assert meta.productivity_weight < 0.5

    def test_known_productive_app(self):
        from utils.categoriser import get_app_meta
        meta = get_app_meta("Khan Academy")
        assert meta.is_productive is True
        assert meta.productivity_weight > 0.8

    def test_unknown_app_fallback(self):
        from utils.categoriser import get_app_meta
        meta = get_app_meta("SomeRandomApp_XYZ")
        assert meta.category in {"Unknown", "Education", "Gaming", "Communication",
                                  "Social Media", "Entertainment"}
        assert 0 <= meta.productivity_weight <= 1

    def test_categorise_dataframe(self, raw_sessions):
        from utils.categoriser import categorise_dataframe
        df = categorise_dataframe(raw_sessions)
        assert "category" in df.columns
        assert "session_score" in df.columns
        assert "productivity_label" in df.columns
        assert df["session_score"].between(0, 100).all()

    def test_productivity_labels_valid(self, raw_sessions):
        from utils.categoriser import categorise_dataframe
        df = categorise_dataframe(raw_sessions)
        valid = {"Productive", "Unproductive", "Neutral"}
        assert set(df["productivity_label"].unique()).issubset(valid)

    def test_score_range(self, raw_sessions):
        from utils.categoriser import categorise_dataframe
        df = categorise_dataframe(raw_sessions)
        assert df["session_score"].min() >= 0
        assert df["session_score"].max() <= 100


# ── Preprocessor tests ─────────────────────────────────────────────────────────

class TestPreprocessor:
    def test_validate_drops_negative_duration(self, raw_sessions):
        from utils.preprocessor import validate
        bad = raw_sessions.copy()
        bad.loc[0, "duration_seconds"] = -100
        cleaned = validate(bad)
        assert len(cleaned) < len(bad)

    def test_validate_drops_zero_duration(self, raw_sessions):
        from utils.preprocessor import validate
        bad = raw_sessions.copy()
        bad.loc[1, "duration_seconds"] = 0
        cleaned = validate(bad)
        assert (cleaned["duration_seconds"] > 0).all()

    def test_enrich_adds_time_features(self, raw_sessions):
        from utils.preprocessor import enrich
        df = enrich(raw_sessions)
        assert "hour" in df.columns
        assert "day_of_week" in df.columns
        assert "time_of_day" in df.columns
        assert "is_weekend" in df.columns

    def test_time_of_day_values(self, raw_sessions):
        from utils.preprocessor import enrich
        df = enrich(raw_sessions)
        valid = {"Morning", "Midday", "Afternoon", "Evening", "Night"}
        assert set(df["time_of_day"].unique()).issubset(valid)

    def test_aggregate_daily_shape(self, raw_sessions):
        from utils.preprocessor import enrich, aggregate_daily
        df = enrich(raw_sessions)
        agg = aggregate_daily(df)
        assert "total_duration_minutes" in agg.columns
        assert "session_count" in agg.columns
        assert (agg["total_duration_minutes"] > 0).all()

    def test_most_frequent_apps(self, raw_sessions):
        from utils.preprocessor import enrich, most_frequent_apps
        df = enrich(raw_sessions)
        top = most_frequent_apps(df, top_n=3)
        assert len(top) <= 3
        assert top["total_sessions"].is_monotonic_decreasing


# ── Trend analyser tests ───────────────────────────────────────────────────────

class TestTrendAnalyser:
    @pytest.fixture
    def day_df(self, raw_sessions):
        from utils.preprocessor import enrich, aggregate_daily_summary
        enriched = enrich(raw_sessions)
        return aggregate_daily_summary(enriched)

    @pytest.fixture
    def session_enriched(self, raw_sessions):
        from utils.preprocessor import enrich
        return enrich(raw_sessions)

    def test_rolling_averages_columns(self, day_df):
        from models.trend_analyser import compute_rolling_averages
        result = compute_rolling_averages(day_df)
        assert "rolling_7d_screen_time" in result.columns
        assert "rolling_7d_productivity" in result.columns

    def test_anomaly_flags(self, day_df):
        from models.trend_analyser import detect_anomalies
        result = detect_anomalies(day_df)
        assert "is_high_usage_day" in result.columns
        assert result["is_high_usage_day"].dtype == bool

    def test_patterns_output(self, session_enriched):
        from models.trend_analyser import detect_patterns
        result = detect_patterns(session_enriched)
        assert "patterns" in result.columns
        assert "user_id" in result.columns
        assert "date" in result.columns

    def test_category_trend_shape(self, session_enriched):
        from models.trend_analyser import category_trend
        result = category_trend(session_enriched)
        assert "category" in result.columns
        assert "duration_minutes" in result.columns


# ── ML Predictor tests ─────────────────────────────────────────────────────────

class TestMLPredictor:
    @pytest.fixture
    def app_daily(self, raw_sessions):
        from utils.preprocessor import enrich, aggregate_daily
        return aggregate_daily(enrich(raw_sessions))

    def test_wma_forecast_returns_dataframe(self, app_daily):
        from models.usage_predictor import wma_forecast
        result = wma_forecast(app_daily, forecast_days=3)
        assert isinstance(result, pd.DataFrame)
        assert "predicted_minutes" in result.columns
        assert (result["predicted_minutes"] >= 0).all()

    def test_wma_forecast_days(self, app_daily):
        from models.usage_predictor import wma_forecast
        result = wma_forecast(app_daily, forecast_days=5)
        dates = result["forecast_date"].nunique()
        assert dates == 5

    def test_rf_train_and_predict(self, app_daily):
        from models.usage_predictor import RFPredictor
        rf = RFPredictor()
        metrics = rf.train(app_daily)
        assert rf.is_trained
        preds = rf.predict_next_days(app_daily, forecast_days=3)
        if not preds.empty:
            assert "predicted_minutes" in preds.columns
            assert (preds["predicted_minutes"] >= 0).all()

    def test_wma_predict_function(self):
        from models.usage_predictor import wma_predict
        series = pd.Series([10, 20, 30, 40])
        result = wma_predict(series)
        assert isinstance(result, float)
        assert result > 0


# ── Notification engine tests ──────────────────────────────────────────────────

class TestNotificationEngine:
    @pytest.fixture
    def app_daily_with_limits(self, raw_sessions):
        from utils.preprocessor import enrich, aggregate_daily
        df = aggregate_daily(enrich(raw_sessions))
        df["limit_exceeded"]   = df["total_duration_minutes"] > df["daily_limit_minutes"]
        df["overage_minutes"]  = (df["total_duration_minutes"] - df["daily_limit_minutes"]).clip(lower=0)
        return df

    def test_limit_exceeded_alerts(self, app_daily_with_limits):
        from reports.notification_engine import check_limit_exceeded
        alerts = check_limit_exceeded(app_daily_with_limits)
        assert isinstance(alerts, list)
        if alerts:
            assert hasattr(alerts[0], "alert_type")
            assert all(a.alert_type == "LIMIT_EXCEEDED" for a in alerts)

    def test_social_spiral_alerts(self, app_daily_with_limits):
        from reports.notification_engine import check_social_spiral
        alerts = check_social_spiral(app_daily_with_limits, limit_mins=5)
        assert isinstance(alerts, list)

    def test_study_praise_alerts(self, app_daily_with_limits):
        from reports.notification_engine import check_study_praise
        alerts = check_study_praise(app_daily_with_limits, praise_mins=5)
        assert isinstance(alerts, list)
        if alerts:
            assert all(a.severity == "info" for a in alerts)

    def test_alert_has_required_fields(self, app_daily_with_limits):
        from reports.notification_engine import check_limit_exceeded
        alerts = check_limit_exceeded(app_daily_with_limits)
        for a in alerts:
            assert a.alert_id
            assert a.title
            assert a.message
            assert a.action
            assert a.severity in {"critical","high","medium","low","info"}


# ── Integration test ───────────────────────────────────────────────────────────

class TestIntegration:
    def test_full_pipeline_on_sample(self, tmp_path, raw_sessions):
        """Run the full pipeline on a small dataset and verify all outputs exist."""
        raw_path = str(tmp_path / "raw.csv")
        out_dir  = str(tmp_path / "out")
        raw_sessions.to_csv(raw_path, index=False)

        from utils.preprocessor import run_preprocessing
        results = run_preprocessing(raw_path, out_dir)

        assert not results["sessions"].empty
        assert not results["app_daily"].empty
        assert not results["day_summary"].empty

        from models.trend_analyser import run_trend_analysis
        trends = run_trend_analysis(results["sessions"], results["day_summary"], out_dir)
        assert not trends["patterns"].empty

        from models.usage_predictor import run_prediction
        pred_results = run_prediction(results["app_daily"], forecast_days=3, output_dir=out_dir)
        assert not pred_results["predictions"].empty

        from reports.notification_engine import run_notifications
        alerts = run_notifications(
            results["sessions"], results["app_daily"],
            results["day_summary"], results["weekly"],
            pred_results["predictions"], output_dir=out_dir
        )
        assert isinstance(alerts, list)

        from reports.report_generator import run_reports
        paths = run_reports(results["day_summary"], results["app_daily"],
                            results["sessions"], alerts, output_dir=out_dir)
        import os
        assert os.path.exists(paths["weekly_report"])
        assert os.path.exists(paths["dataset"])


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
