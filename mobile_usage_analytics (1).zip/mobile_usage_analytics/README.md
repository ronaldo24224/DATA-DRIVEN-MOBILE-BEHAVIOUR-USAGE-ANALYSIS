# Mobile Behaviour Usage Analytics

A full-stack data pipeline and analytics system for analysing mobile app usage, deriving productivity scores, predicting future usage with ML, and generating automated reports.

## Project Structure

```
mobile_usage_analytics/
├── sample_data/
│   └── generate_sample_data.py     # Generate synthetic usage logs for testing
├── data/
│   └── (raw + processed data lands here)
├── utils/
│   ├── categoriser.py              # App categorisation & productivity scoring
│   └── preprocessor.py            # Raw log ingestion & cleaning
├── models/
│   ├── usage_predictor.py          # ML model: predict tomorrow's usage
│   └── trend_analyser.py           # Trend detection & anomaly flagging
├── reports/
│   ├── report_generator.py         # Weekly/monthly report generation
│   └── notification_engine.py      # Threshold alerts & nudges
├── dashboard/
│   └── app.py                      # Streamlit web dashboard
├── pipeline.py                     # End-to-end pipeline runner
├── requirements.txt
└── README.md
```

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Generate sample data
python sample_data/generate_sample_data.py

# 3. Run the full pipeline (ingest → process → model → report)
python pipeline.py

# 4. Launch the interactive dashboard
streamlit run dashboard/app.py
```

## Output Files

After running the pipeline, check `data/` for:
- `processed_usage.csv`      — cleaned, categorised, scored dataset
- `predictions.csv`          — ML predictions for the next 7 days
- `weekly_report.html`       — formatted weekly report
- `alerts.json`              — triggered notifications

## App Categories

| Category       | Productivity | Examples                        |
|----------------|-------------|----------------------------------|
| Education      | High        | Khan Academy, Duolingo, Coursera |
| Productivity   | High        | Notion, Google Docs, Calendar    |
| Communication  | Medium      | WhatsApp, Gmail, Slack           |
| Utility        | Medium      | Maps, Camera, Settings           |
| Entertainment  | Low         | YouTube, Netflix, Spotify        |
| Social Media   | Low         | Instagram, TikTok, Twitter       |
| Gaming         | Low         | Mobile Legends, PUBG, Candy Crush|
